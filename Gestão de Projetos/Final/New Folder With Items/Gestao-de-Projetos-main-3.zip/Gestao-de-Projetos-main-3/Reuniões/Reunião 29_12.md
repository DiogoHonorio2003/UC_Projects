**Ata da Reunião – 29/12/2025**



Data: 29 de dezembro de 2025

Tipo de reunião: Reunião de acompanhamento do projeto

Participantes: Equipa do projeto (backend, frontend e testing)





**Objetivo da Reunião**



Dar continuidade ao desenvolvimento do projeto, permitindo que cada equipa trabalhasse nas tarefas que lhe foram atribuídas, de acordo com o planeamento definido.





**Resumo do que foi realizado**



Durante a reunião, os elementos do grupo dividiram-se pelas respetivas equipas funcionais:



* **Equipa de Backend**:

Trabalhou no desenvolvimento das funcionalidades da API, dando continuidade à implementação das operações previstas para o sistema.



* **Equipa de Frontend**:

Desenvolveu e refinou interfaces da aplicação móvel, bem como a integração com as funcionalidades já disponíveis no backend.



* **Equipa de Testing**:

Acompanhou o progresso das restantes equipas e realizou testes às funcionalidades implementadas, identificando possíveis problemas.



**Conclusões**



A reunião permitiu avançar no desenvolvimento do projeto de forma coordenada entre as equipas, garantindo alinhamento com o planeamento estabelecido.



**Próximos Passos**



* Continuar o desenvolvimento das funcionalidades planeadas.
* Corrigir eventuais problemas identificados durante os testes.
* Preparar as próximas tarefas de acordo com o cronograma do projeto.
