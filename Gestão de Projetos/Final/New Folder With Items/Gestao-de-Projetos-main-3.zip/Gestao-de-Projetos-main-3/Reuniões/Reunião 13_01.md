**Ata da Reunião – 13/01/2026**



Data: 13 de janeiro de 2026

Tipo de reunião: Reunião de acompanhamento do projeto

Participantes: Equipa do projeto (backend, frontend e testing)





**Objetivo da Reunião**

Dar continuidade ao desenvolvimento do projeto, permitindo que cada equipa trabalhasse nas tarefas planeadas para a fase atual.





**Resumo do que foi realizado**

Durante a reunião, os membros do grupo organizaram-se pelas respetivas equipas funcionais:



* **Equipa de Backend**:

Prosseguiu o desenvolvimento e melhoria das funcionalidades da API, de acordo com os requisitos definidos.



* **Equipa de Frontend**:

Continuou a implementação da aplicação móvel e a integração com as funcionalidades disponibilizadas pelo backend.



* **Equipa de Testing**:

Executou testes às funcionalidades desenvolvidas, acompanhando a evolução do sistema e registando eventuais problemas.





**Conclusões**

A reunião permitiu avançar no desenvolvimento do projeto de forma coordenada, mantendo o alinhamento entre as diferentes equipas.





**Próximos Passos**

* Continuar o desenvolvimento das funcionalidades previstas.
* Dar seguimento aos testes e correções necessárias.
* Preparar as tarefas das próximas semanas conforme o planeamento definido.
