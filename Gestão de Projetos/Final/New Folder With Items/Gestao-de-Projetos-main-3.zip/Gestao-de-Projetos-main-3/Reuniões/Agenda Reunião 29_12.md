**Agenda da Reunião – 29/12/2025**



Data: 29 de dezembro de 2025

Tipo de reunião: Reunião de acompanhamento do projeto





**Pontos da Agenda**



1. Acompanhamento do progresso do projeto



2\. Trabalho em equipa por área funcional:

* Backend
* Frontend
* Testing



3\. Identificação de eventuais dificuldades técnicas



4\. Definição dos próximos passos

