**Agenda da Reunião – 13/01/2026**



Data: 13 de janeiro de 2026

Tipo de reunião: Reunião de acompanhamento do projeto



**Pontos da Agenda**

1. Acompanhamento do estado atual do projeto



2\. Trabalho por equipas:



* Backend
* Frontend
* Testing



3\. Identificação de dificuldades ou bloqueios



4\. Planeamento das próximas tarefas

