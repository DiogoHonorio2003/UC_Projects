import { prisma } from './lib/prisma.js';
import { Logger } from './utils/logger.js';

async function runBenchmark() {
  Logger.info('Iniciando benchmark da base de dados...');

  const iterations = 10000;
  const startTime = Date.now();

  try {
    // 1. Teste de Leitura (FindMany)
    Logger.info(`A executar ${iterations} leituras de utilizadores...`);
    for (let i = 0; i < iterations; i++) {
      await prisma.user.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' }
      });
    }

    const midTime = Date.now();
    Logger.info(`Leituras concluídas em ${midTime - startTime}ms`);

    // 2. Teste de Escrita (AuditLog - Tabela que costuma crescer rápido)
    Logger.info(`A executar ${iterations} escritas em AuditLog...`);
    for (let i = 0; i < iterations; i++) {
        await prisma.auditLog.create({
            data: {
                userId: 1, // Assumindo que o Admin ID é 1
                action: 'BENCHMARK_TEST',
                entity: 'System',
                entityId: '0',
                details: { info: `Iteration ${i}` }
            }
        });
    }

    const endTime = Date.now();
    Logger.info(`Escritas concluídas em ${endTime - midTime}ms`);
    Logger.info(`Benchmark total concluído em ${endTime - startTime}ms`);

  } catch (error) {
    Logger.error('Erro durante o benchmark:', error);
  } finally {
    await prisma.$disconnect();
  }
}

runBenchmark();
