import { Router } from 'express';
import { UsersController } from '../controllers/users.controller.js';
import { authenticate } from '../middlewares/auth.middleware.js';
import { requireRole } from '../middlewares/roles.middleware.js';

const usersRouter = Router();

// Todas as rotas requerem autenticação
usersRouter.use(authenticate);

// GET /users - Listar todos os utilizadores (Admin only)
usersRouter.get('/', requireRole('ADMIN'), UsersController.getAllUsers);

// GET /users/:id - Obter utilizador por ID (Admin only)
usersRouter.get('/:id', requireRole('ADMIN'), UsersController.getUserById);

// PUT /users/:id - Atualizar utilizador (Admin only)
usersRouter.put('/:id', requireRole('ADMIN'), UsersController.updateUser);

// PUT /users/:id/deactivate - Desativar utilizador (Admin only)
usersRouter.put('/:id/deactivate', requireRole('ADMIN'), UsersController.deactivateUser);

// PUT /users/:id/activate - Ativar utilizador (Admin only)
usersRouter.put('/:id/activate', requireRole('ADMIN'), UsersController.activateUser);

export { usersRouter };
