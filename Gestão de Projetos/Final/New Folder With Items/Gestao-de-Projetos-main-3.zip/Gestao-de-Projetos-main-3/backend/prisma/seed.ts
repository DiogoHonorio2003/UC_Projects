import { prisma } from '../src/lib/prisma.js';
import { PartCondition } from '@prisma/client';
import bcrypt from 'bcryptjs';

async function ensureSpecification(name: string, unit?: string | null) {
  const existing = await prisma.specification.findFirst({ where: { name } });
  if (existing) return existing;
  return prisma.specification.create({ data: { name, unit: unit ?? undefined } });
}

async function ensureCategory(name: string, parentId?: number | null) {
  const existing = await prisma.category.findFirst({ where: { name, parentId: parentId ?? undefined } });
  if (existing) return existing;
  return prisma.category.create({ data: { name, parentId: parentId ?? undefined } });
}

async function ensureSupplier(name: string, contact?: string | null) {
  const existing = await prisma.supplier.findFirst({ where: { name } });
  if (existing) return existing;
  return prisma.supplier.create({ data: { name, contact: contact ?? undefined } });
}

async function main() {
  console.log('🌱 A iniciar o seeding...');

  const passwordHash = await bcrypt.hash('123456Tt', 10);

  // Utilizadores base
  await prisma.user.upsert({
    where: { email: 'admin@fundapecas.pt' },
    update: {},
    create: { username: 'admin', email: 'admin@fundapecas.pt', fullName: 'Sr. Administrador', passwordHash, role: 'ADMIN' },
  });
  await prisma.user.upsert({
    where: { email: 'warehouse@fundapecas.pt' },
    update: {},
    create: { username: 'warehouse', email: 'warehouse@fundapecas.pt', fullName: 'Gestor Armazém', passwordHash, role: 'WAREHOUSE' },
  });
  await prisma.user.upsert({
    where: { email: 'sales@fundapecas.pt' },
    update: {},
    create: { username: 'sales', email: 'sales@fundapecas.pt', fullName: 'Comercial', passwordHash, role: 'SALES' },
  });
  await prisma.user.upsert({
    where: { email: 'cliente@fundapecas.pt' },
    update: {},
    create: { username: 'cliente', email: 'cliente@fundapecas.pt', fullName: 'Cliente Demo', passwordHash, role: 'CLIENT' },
  });

  // Armazéns e localizações
  // --- ARMAZÉNS E LOCALIZAÇÕES (Mapeamento das Imagens) ---

  // 1. ARMAZÉM DE CIMA
  const warehouseCima = await prisma.warehouse.upsert({
    where: { code: 'ACIMA' },
    update: {},
    create: {
      code: 'ACIMA',
      name: 'Armazém de Cima',
    },
  });

  const racksCima = [
    'A01','A02','A03','A04','A05','A06',
    'B01','B02','B03','B04','B05','B06',
    'C01','C02','C03','C04','C05','C06','C07','C08','C09',
    'D01','D02','D03','D04','D05','D06','D07',
    'E01','E02','E03','E04','E05','E06','E07',
    'F01','F02','F03','F04','F05','F06','F07'
  ];

  for (const rackCode of racksCima) {
    const isD07 = rackCode === 'D07';
    const maxShelf = isD07 ? 5 : 4; // D07 tem nível 5 nas fotos

    for (let s = 0; s <= maxShelf; s++) {
      const positions = s === 5 ? ['P', 'Q', 'R'] : ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O'];
      
      // Filtrar apenas as letras correspondentes ao nível conforme a imagem (A-C nível 0, D-F nível 1, etc.)
      const levelLetters = positions.slice(s * 3, (s * 3) + 3);

      for (const pos of levelLetters) {
        const fullCode = `ACIMA-${rackCode}-${s}-${pos}`;
        await prisma.location.upsert({
          where: { fullCode },
          update: {},
          create: {
            fullCode,
            warehouseId: warehouseCima.id,
            rack: rackCode,
            shelf: s.toString(),
            pallet: pos,
            capacity: 1
          }
        });
      }
    }
  }

  // 2. ARMAZÉM DE BAIXO
  const warehouseBaixo = await prisma.warehouse.upsert({
    where: { code: 'ABAIXO' },
    update: {},
    create: {
      code: 'ABAIXO',
      name: 'Armazém de Baixo',
    },
  });

  const racksBaixo = {
    'A': { start: 7, end: 17 },
    'B': { start: 6, end: 15 },
    'C': { start: 6, end: 15 },
    'D': { start: 6, end: 16 }
  };

  for (const [letter, range] of Object.entries(racksBaixo)) {
    for (let i = range.start; i <= range.end; i++) {
      const rackCode = `${letter}${i.toString().padStart(2, '0')}`;
      for (let s = 0; s <= 4; s++) {
        const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O'];
        const levelLetters = letters.slice(s * 3, (s * 3) + 3);
        
        for (const pos of levelLetters) {
          const fullCode = `ABAIXO-${rackCode}-${s}-${pos}`;
          await prisma.location.upsert({
            where: { fullCode },
            update: {},
            create: { fullCode, warehouseId: warehouseBaixo.id, rack: rackCode, shelf: s.toString(), pallet: pos }
          });
        }
      }
    }
  }

  // 3. PRATELEIRAS - CAIXAS
  const warehouseCaixas = await prisma.warehouse.upsert({
    where: { code: 'CAIXAS' },
    update: {},
    create: { code: 'CAIXAS', name: 'Prateleiras - Caixas' },
  });

  const caixas = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','T','S','U','V','W','X'];
  for (const caixa of caixas) {
    await prisma.location.upsert({
      where: { fullCode: `CX-${caixa}` },
      update: {},
      create: {
        fullCode: `CX-${caixa}`,
        warehouseId: warehouseCaixas.id,
        rack: 'SALA_CAIXAS',
        shelf: '1',
        pallet: `Caixa ${caixa}`
      }
    });
  }

  // 4. PAVILHÃO 2
  const warehousePav2 = await prisma.warehouse.upsert({
    where: { code: 'PAV2' },
    update: {},
    create: { code: 'PAV2', name: 'Pavilhão 2' },
  });

  for (let i = 1; i <= 15; i++) {
    const rackCode = i.toString().padStart(2, '0');
    await prisma.location.upsert({
      where: { fullCode: `PAV2-${rackCode}` },
      update: {},
      create: {
        fullCode: `PAV2-${rackCode}`,
        warehouseId: warehousePav2.id,
        rack: rackCode,
        shelf: '0',
        capacity: 10
      }
    });
  }

  // Especificações
  const specVoltagem = await ensureSpecification('Voltagem', 'V');
  const specAmperagem = await ensureSpecification('Amperagem', 'A');
  const specPeso = await ensureSpecification('Peso', 'kg');
  const specLado = await ensureSpecification('Lado', null);

  // Categorias
  const catMotor = await ensureCategory('Motor');
  const catTravagem = await ensureCategory('Travagem');
  const catEletrico = await ensureCategory('Componentes Elétricos', catMotor.id);
  const catFiltros = await ensureCategory('Filtros');

  // Suppliers
  const supplierBosch = await ensureSupplier('Bosch', 'bosch@example.com');
  const supplierValeo = await ensureSupplier('Valeo', 'valeo@example.com');

  // Helper to find location IDs
  const locCimaRackA01Shelf0A = await prisma.location.findUnique({ where: { fullCode: 'ACIMA-A01-0-A' } });
  const locCimaRackA01Shelf0B = await prisma.location.findUnique({ where: { fullCode: 'ACIMA-A01-0-B' } });
  const locCimaRackA01Shelf1D = await prisma.location.findUnique({ where: { fullCode: 'ACIMA-A01-1-D' } });
  const locAbaixoA07Shelf0A = await prisma.location.findUnique({ where: { fullCode: 'ABAIXO-A07-0-A' } });

  // Parts (mix of conditions, locations, specs)
  if (locCimaRackA01Shelf0A && locCimaRackA01Shelf0B && locCimaRackA01Shelf1D && locAbaixoA07Shelf0A) {
    await prisma.part.create({
      data: {
        name: 'Alternador BMW E46',
        refInternal: 'ALT-BMW-001',
        refOEM: '12317501599',
        price: 85.0,
        condition: PartCondition.USED,
        categoryId: catEletrico.id,
        supplierId: supplierBosch.id,
        locationId: locCimaRackA01Shelf0A.id,
        specifications: { create: [ { specId: specVoltagem.id, value: '12' }, { specId: specAmperagem.id, value: '150' } ] },
        subReferences: { create: [ { value: '0986041500' }, { value: 'LRA02854' } ] },
      },
    });

    await prisma.part.create({
      data: {
        name: 'Disco de Travão VW Golf',
        refInternal: 'BRK-VW-010',
        refOEM: '1K0615301AA',
        price: 45.5,
        condition: PartCondition.NEW,
        categoryId: catTravagem.id,
        supplierId: supplierValeo.id,
        locationId: locCimaRackA01Shelf0B.id,
        specifications: { create: [ { specId: specPeso.id, value: '6.2' } ] },
        subReferences: { create: [ { value: 'DF1234' } ] },
      },
    });

    await prisma.part.create({
      data: {
        name: 'Filtro de Óleo Renault',
        refInternal: 'OIL-REN-007',
        refOEM: '7700274177',
        price: 12.3,
        condition: PartCondition.NEW,
        categoryId: catFiltros.id,
        supplierId: supplierBosch.id,
        locationId: locAbaixoA07Shelf0A.id,
        specifications: { create: [ { specId: specPeso.id, value: '0.4' } ] },
        subReferences: { create: [ { value: 'OX123' } ] },
      },
    });

    await prisma.part.create({
      data: {
        name: 'Sensor ABS BMW',
        refInternal: 'ABS-BMW-003',
        refOEM: '34526756381',
        price: 28.9,
        condition: PartCondition.USED,
        categoryId: catEletrico.id,
        supplierId: supplierValeo.id,
        locationId: locCimaRackA01Shelf1D.id,
        specifications: { create: [ { specId: specLado.id, value: 'Esquerdo' } ] },
        subReferences: { create: [ { value: 'GIC198' } ] },
      },
    });
  }

  console.log('✅ Seeding concluído');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });