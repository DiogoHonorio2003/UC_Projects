import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  stages: [
    { duration: '30s', target: 20 },
    { duration: '1m', target: 20 },
    { duration: '30s', target: 0 },
  ],
};

const BASE_URL = __ENV.BASE_URL || 'http://localhost:3002';

// Função de Setup para obter o Token
export function setup() {
  const loginPayload = JSON.stringify({
    username: 'admin',
    password: '123456Tt',
  });

  const params = {
    headers: {
      'Content-Type': 'application/json',
    },
  };

  const res = http.post(`${BASE_URL}/auth/login`, loginPayload, params);
  
  if (res.status !== 200) {
    console.log(`Login failed during setup! Status: ${res.status}`);
    return { token: null };
  }

  return { token: res.json().accessToken };
}

export default function (data) {
  const params = {
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${data.token}`,
    },
  };

  // 1. Testar Listagem de Peças (Leitura)
  const resParts = http.get(`${BASE_URL}/parts`, params);
  check(resParts, {
    'parts status is 200': (r) => r.status === 200,
  });

  sleep(1);

  // 2. Testar Get Profile (Outra leitura)
  const resMe = http.get(`${BASE_URL}/auth/me`, params);
  check(resMe, {
    'profile status is 200': (r) => r.status === 200,
  });

  sleep(1);
}
