// jest.unit.config.js - For unit tests (controllers, services, middlewares)
export default {
    preset: 'ts-jest/presets/default-esm',
    testEnvironment: 'node',
    moduleFileExtensions: ['ts', 'js', 'json'],
    rootDir: '.',
    extensionsToTreatAsEsm: ['.ts'],
    testMatch: [
        '**/__tests__/controllers/**/*.test.ts',
        '**/__tests__/services/**/*.test.ts',
        '**/__tests__/middlewares/**/*.test.ts'
    ],
    collectCoverageFrom: [
        'src/**/*.ts',
        '!src/**/*.d.ts',
        '!src/**/index.ts',
    ],
    coverageDirectory: 'coverage',
    verbose: true,
    moduleNameMapper: {
        '^(\\.{1,2}/.*)\\.js$': '$1',
    },
    transform: {
        '^.+\\.tsx?$': [
            'ts-jest',
            {
                useESM: true,
                isolatedModules: true,
                tsconfig: 'tsconfig.json',
            },
        ],
    },
};
