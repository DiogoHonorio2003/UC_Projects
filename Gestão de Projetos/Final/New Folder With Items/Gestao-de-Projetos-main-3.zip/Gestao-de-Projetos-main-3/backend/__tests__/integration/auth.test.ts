import request from 'supertest';
import { app } from '../../src/app.js';
import { prisma } from '../../src/lib/prisma.js';
import bcrypt from 'bcryptjs';

// No reset-db import, as requested by user.

describe('Auth Integration (No DB Clean)', () => {

    afterAll(async () => {
        await prisma.$disconnect();
    });

    describe('POST /auth/login', () => {
        it('should login successfully with valid credentials', async () => {
            // 1. Create a user manually with UNIQUE data to avoid conflicts
            // Using a random suffix based on timestamp + random number
            const uniqueSuffix = `${Date.now()}_${Math.floor(Math.random() * 1000)}`;
            const username = `testuser_${uniqueSuffix}`;
            const email = `testuser_${uniqueSuffix}@example.com`;
            const password = 'password123';
            const hashedPassword = await bcrypt.hash(password, 10);

            const user = await prisma.user.create({
                data: {
                    username,
                    email,
                    fullName: 'Test Login User',
                    passwordHash: hashedPassword,
                    role: 'CLIENT',
                    isActive: true
                }
            });

            try {
                // 2. Attempt login
                const res = await request(app)
                    .post('/auth/login')
                    .send({
                        username: user.username,
                        password: password
                    });

                // 3. Verify response
                expect(res.status).toBe(200);
                expect(res.body).toHaveProperty('accessToken');
                expect(res.body).toHaveProperty('refreshToken');
                expect(res.body.user).toHaveProperty('id', user.id);
                expect(res.body.user).toHaveProperty('username', user.username);
            } finally {
                // Clean up this specific user to be polite, even if we don't wipe the DB
                // This is a "surgical" cleanup that respects the "don't clean DB" rule (for other data)
                await prisma.user.delete({ where: { id: user.id } }).catch(() => { });
            }
        });

        it('should return 401 with invalid credentials', async () => {
            const res = await request(app)
                .post('/auth/login')
                .send({
                    username: 'nonexistent_user',
                    password: 'wrongpassword'
                });

            expect(res.status).toBe(401);
        });
    });
});
