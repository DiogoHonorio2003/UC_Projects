import request from 'supertest';
import { app } from '../../src/app.js';
import { prisma } from '../../src/lib/prisma.js';
import bcrypt from 'bcryptjs';

describe('Parts Integration', () => {
    let adminToken: string;
    let initialCategoryId: number;
    let createdPartRef: string;

    beforeAll(async () => {
        // 1. Setup Admin User
        const uniqueSuffix = `${Date.now()}_${Math.floor(Math.random() * 1000)}`;
        const adminEmail = `admin_parts_${uniqueSuffix}@example.com`;
        const adminPassword = 'password123';
        const hashedPassword = await bcrypt.hash(adminPassword, 10);

        const admin = await prisma.user.create({
            data: {
                username: `admin_parts_${uniqueSuffix}`,
                email: adminEmail,
                fullName: 'Admin Parts Test',
                passwordHash: hashedPassword,
                role: 'ADMIN',
                isActive: true,
                passwordUpdatedAt: new Date(Date.now() - 3600000) // 1 hour ago
            }
        });

        // 2. Login to get token
        const loginRes = await request(app)
            .post('/auth/login')
            .send({ username: admin.username, password: adminPassword });

        adminToken = loginRes.body.accessToken;

        // 3. Ensure a Category exists
        // Try to find one first to avoid pollution
        const existingCat = await prisma.category.findFirst({ where: { deletedAt: null } });
        if (existingCat) {
            initialCategoryId = existingCat.id;
        } else {
            const newCat = await prisma.category.create({
                data: {
                    name: `Test Category ${uniqueSuffix}`
                }
            });
            initialCategoryId = newCat.id;
        }
    });

    afterAll(async () => {
        // Cleanup the part we created
        if (createdPartRef) {
            try {
                await prisma.part.deleteMany({ where: { refInternal: createdPartRef } });
            } catch (e) {
                console.log('Cleanup failed (expected if dependencies exist):', e);
            }
        }
        await prisma.$disconnect();
    });

    it('should create a new part', async () => {
        const uniqueSuffix = `${Date.now()}_${Math.floor(Math.random() * 1000)}`;
        const partData = {
            name: `Test Part ${uniqueSuffix}`,
            refInternal: `REF_${uniqueSuffix}`,
            price: 150.50,
            condition: 'NEW',
            categoryId: initialCategoryId,
            locationId: 1, // Assumptions: Location 1 exists. If not, this might fail unless we mock/create location too.
            // Actually, let's create a location in beforeAll to be safe.
        };

        // Fix: Create location if not exists
        const existingLoc = await prisma.location.findFirst();
        if (existingLoc) {
            partData.locationId = existingLoc.id; // Use real locaation id
        } else {
            const warehouse = await prisma.warehouse.create({
                data: { code: `WH_${uniqueSuffix}`, name: 'Test Warehouse' }
            });
            const location = await prisma.location.create({
                data: {
                    warehouseId: warehouse.id,
                    rack: 'A',
                    shelf: '1',
                    fullCode: `A-1-${uniqueSuffix}`,
                    capacity: 100
                }
            });
            partData.locationId = location.id;
        }

        const res = await request(app)
            .post('/parts')
            .set('Authorization', `Bearer ${adminToken}`)
            .send(partData);

        if (res.status !== 201) console.log('Create Part Error:', res.body);

        expect(res.status).toBe(201);
        expect(res.body).toHaveProperty('id');
        expect(res.body.refInternal).toBe(partData.refInternal);

        createdPartRef = partData.refInternal;
    });

    it('should retrieve the created part by ref', async () => {
        expect(createdPartRef).toBeDefined();

        const res = await request(app)
            .get(`/parts/${createdPartRef}`)
            .set('Authorization', `Bearer ${adminToken}`);

        expect(res.status).toBe(200);
        expect(res.body.refInternal).toBe(createdPartRef);
    });

    it('should list all parts', async () => {
        const res = await request(app)
            .get('/parts')
            .set('Authorization', `Bearer ${adminToken}`);

        expect(res.status).toBe(200);
        expect(Array.isArray(res.body)).toBe(true);
        // Should contain our part
        const found = res.body.find((p: any) => p.refInternal === createdPartRef);
        expect(found).toBeDefined();
    });
});
