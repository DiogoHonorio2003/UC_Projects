import request from 'supertest';
import { app } from '../../src/app.js';
import { prisma } from '../../src/lib/prisma.js';
import bcrypt from 'bcryptjs';

describe('Reservations Integration', () => {
    let salesToken: string;
    let createdPartId: number;
    let initialCategoryId: number; // Define this variable
    let initialLocationId: number;

    beforeAll(async () => {
        // 1. Setup Sales User
        const uniqueSuffix = `${Date.now()}_${Math.floor(Math.random() * 1000)}`;
        const salesEmail = `sales_${uniqueSuffix}@example.com`;
        const salesPassword = 'password123';
        const hashedPassword = await bcrypt.hash(salesPassword, 10);

        const salesUser = await prisma.user.create({
            data: {
                username: `sales_${uniqueSuffix}`,
                email: salesEmail,
                fullName: 'Sales Test User',
                passwordHash: hashedPassword,
                role: 'SALES',
                isActive: true,
                passwordUpdatedAt: new Date(Date.now() - 3600000) // 1 hour ago
            }
        });

        // 2. Login
        const loginRes = await request(app)
            .post('/auth/login')
            .send({ username: salesUser.username, password: salesPassword });

        salesToken = loginRes.body.accessToken;

        // 3. Create a Category and Part
        // Ensure category
        const existingCat = await prisma.category.findFirst({ where: { deletedAt: null } });
        if (existingCat) {
            initialCategoryId = existingCat.id;
        } else {
            const newCat = await prisma.category.create({
                data: { name: `Test Category Res ${uniqueSuffix}` }
            });
            initialCategoryId = newCat.id;
        }

        // Ensure Location
        const existingLoc = await prisma.location.findFirst();
        if (existingLoc) {
            initialLocationId = existingLoc.id;
        } else {
            const warehouse = await prisma.warehouse.create({
                data: { code: `WH_${uniqueSuffix}`, name: 'Test Warehouse' }
            });
            const loc = await prisma.location.create({
                data: {
                    warehouseId: warehouse.id,
                    rack: 'A',
                    shelf: '1',
                    fullCode: `A-1-${uniqueSuffix}`,
                    capacity: 100
                }
            });
            initialLocationId = loc.id;
        }

        const part = await prisma.part.create({
            data: {
                name: `Part for Reservation ${uniqueSuffix}`,
                refInternal: `REF_RES_${uniqueSuffix}`,
                price: 100,
                category: { connect: { id: initialCategoryId } },
                location: { connect: { id: initialLocationId } }
            }
        });
        createdPartId = part.id;
    });

    afterAll(async () => {
        // Cleanup part
        if (createdPartId) {
            await prisma.part.delete({ where: { id: createdPartId } }).catch(() => { });
        }
        await prisma.$disconnect();
    });

    it('should create a reservation', async () => {
        const res = await request(app)
            .post('/reservations')
            .set('Authorization', `Bearer ${salesToken}`)
            .send({
                partId: createdPartId,
                notes: 'Test Reservation Note'
            });

        // Note: I don't recall the exact createReservation Payload from the provided files, 
        // will need to check controller if 400.
        // But for now typical fields: partId is mandatory.

        if (res.status !== 201) console.log('Create Reservation Error:', res.body);
        expect(res.status).toBe(201);
        expect(res.body).toHaveProperty('id');
    });

    it('should list reservations', async () => {
        const res = await request(app)
            .get('/reservations')
            .set('Authorization', `Bearer ${salesToken}`);

        expect(res.status).toBe(200);
        expect(Array.isArray(res.body)).toBe(true);
    });
});
