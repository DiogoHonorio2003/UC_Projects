import request from 'supertest';
import { app } from '../../src/app.js';
import { prisma } from '../../src/lib/prisma.js';

describe('Health Check Integration', () => {
    afterAll(async () => {
        await prisma.$disconnect();
    });

    it('should return 404 for unknown route', async () => {
        // Just a simple check to ensure the app is mounting routes and responding
        const res = await request(app).get('/api/health-check-non-existent');
        expect(res.status).toBe(404);
    });
});
