# Gestao-de-Projetos
Fundapeças App



# Testes

## Install K6 on Windows

On Admin PowerShell:
```bash
winget install k6 --source winget
```


## Load DB benchmark

```bash
k6 run --summary-export=load_test_summary.json load-test.js
```