import React, { useState } from "react";
import {
  View,
  TextInput,
  StyleSheet,
  TouchableOpacity,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

type SearchBarProps = {
  placeholder?: string;
  value?: string;
  onSearch?: (text: string) => void;
  onChangeText?: (text: string) => void;
};

export default function SearchBar({
  placeholder = "Pesquisar peças...",
  value,
  onSearch,
  onChangeText,
}: SearchBarProps) {
  const [searchText, setSearchText] = useState(value || "");

  // Sincronizar com o value externo
  React.useEffect(() => {
    if (value !== undefined) {
      setSearchText(value);
    }
  }, [value]);

  const handleChangeText = (text: string) => {
    setSearchText(text);
    // Remove a chamada automática do onChangeText
    // para não filtrar enquanto digita
  };

  const handleSearch = () => {
    console.log("Pesquisa realizada:", searchText);
    // Mantém o texto na barra após pesquisar
    onSearch?.(searchText);
  };

  const handleClear = () => {
    setSearchText("");
    // Limpa a pesquisa e volta a mostrar todas as peças
    onSearch?.("");
  };

  return (
    <View style={styles.container}>
      <View style={styles.searchContainer}>
        <Ionicons
          name="search-outline"
          size={20}
          color="#9ca3af"
          style={styles.searchIcon}
        />
        
        <TextInput
          style={styles.input}
          placeholder={placeholder}
          placeholderTextColor="#9ca3af"
          value={searchText}
          onChangeText={handleChangeText}
          onSubmitEditing={handleSearch}
          returnKeyType="search"
        />

        {searchText.length > 0 && (
          <TouchableOpacity
            onPress={handleClear}
            activeOpacity={0.7}
            style={styles.clearButton}
          >
            <Ionicons
              name="close-circle"
              size={20}
              color="#9ca3af"
            />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 16,
    paddingVertical: 12,
    elevation: 2,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 2,
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f3f4f6",
    borderRadius: 8,
    paddingHorizontal: 12,
    height: 44,
  },
  searchIcon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: "#333",
    padding: 0,
  },
  clearButton: {
    marginLeft: 8,
    padding: 4,
  },
});