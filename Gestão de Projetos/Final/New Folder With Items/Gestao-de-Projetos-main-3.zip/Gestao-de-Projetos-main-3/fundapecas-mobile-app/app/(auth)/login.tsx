import { useState } from "react";
import {
  Text,
  TextInput,
  TouchableOpacity,
  View,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Image,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { login, validateLoginFields, ApiError } from "../(services)/authService";

export default function LoginScreen() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleLogin = async () => {
    // Limpa mensagens anteriores
    setErrorMessage("");
    setSuccessMessage("");

    // Validação dos campos
    const validation = validateLoginFields(username, password);
    if (!validation.valid) {
      setErrorMessage(validation.message!);
      return;
    }

    setLoading(true);

    let didSucceed = false;

    try {
      const response = await login({ username, password });
      didSucceed = true;

      // Mensagem bonita + nome do utilizador
      const displayName = response.user?.fullName || response.user?.username || username;
      setSuccessMessage(`Bem-vindo, ${displayName}!`);

      // Importante: NÃO limpar campos aqui (evita o "apagou tudo" feio)
      // Navega após um delay curto só para a mensagem aparecer
      setTimeout(() => {
        router.replace("/home");
      }, 600);
    } catch (error) {
      const apiError = error as ApiError;
      console.error("Erro de login:", apiError);

      // Limpa a password por segurança
      setPassword("");

      if (apiError.statusCode === 401) {
        setErrorMessage("Username ou password incorretos.");
      } else if (apiError.statusCode === 0) {
        setErrorMessage("Erro de conexão. Verifica se o servidor está ativo.");
      } else {
        setErrorMessage(apiError.message || "Erro ao fazer login. Tenta novamente.");
      }
    } finally {
      // Se foi sucesso, mantemos o loading até ao router.replace (evita flicker)
      if (!didSucceed) setLoading(false);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-white">
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        className="flex-1"
      >
        <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled">
          <View className="flex-1 justify-center items-center px-8">
            {/* Logo */}
            <View className="items-center mb-12">
              <Image
                source={require("../../assets/images/fundapecas.png")}
                style={{ width: 120, height: 120, marginBottom: 24 }}
                resizeMode="contain"
              />

              <Text className="text-4xl font-bold text-gray-800 mb-2">FUNDAPEÇAS</Text>
              <Text className="text-base text-gray-500">Sistema de Gestão de Peças</Text>
            </View>

            {/* Form */}
            <View className="w-full max-w-sm">
              {/* Username Input */}
              <View className="mb-4">
                <Text className="text-sm font-medium text-gray-700 mb-2">Username</Text>
                <View className="flex-row items-center bg-blue-50 rounded-xl px-4 py-3 border border-blue-100">
                  <Ionicons name="person-outline" size={20} color="#3b82f6" />
                  <TextInput
                    testID="username-input"
                    className="flex-1 ml-3 text-base text-gray-800"
                    placeholder="Introduz o teu username"
                    placeholderTextColor="#9ca3af"
                    autoCapitalize="none"
                    value={username}
                    onChangeText={(text) => {
                      setUsername(text);
                      setErrorMessage("");
                      setSuccessMessage("");
                    }}
                    editable={!loading}
                  />
                </View>
              </View>

              {/* Password Input */}
              <View className="mb-6">
                <Text className="text-sm font-medium text-gray-700 mb-2">Palavra-passe</Text>
                <View className="flex-row items-center bg-blue-50 rounded-xl px-4 py-3 border border-blue-100">
                  <Ionicons name="lock-closed-outline" size={20} color="#3b82f6" />
                  <TextInput
                    testID="password-input"
                    className="flex-1 ml-3 text-base text-gray-800"
                    placeholder="Introduz a tua palavra-passe"
                    placeholderTextColor="#9ca3af"
                    secureTextEntry={!showPassword}
                    value={password}
                    onChangeText={(text) => {
                      setPassword(text);
                      setErrorMessage("");
                      setSuccessMessage("");
                    }}
                    onSubmitEditing={handleLogin}
                    editable={!loading}
                  />
                  <TouchableOpacity onPress={() => setShowPassword(!showPassword)} disabled={loading}>
                    <Ionicons
                      name={showPassword ? "eye-outline" : "eye-off-outline"}
                      size={20}
                      color="#9ca3af"
                    />
                  </TouchableOpacity>
                </View>
              </View>

              {/* Mensagem de Erro */}
              {errorMessage ? (
                <View className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 mb-4 flex-row items-center">
                  <Ionicons name="alert-circle-outline" size={20} color="#dc2626" />
                  <Text testID="error_message" className="text-red-600 text-sm ml-2 flex-1">
                    {errorMessage}
                  </Text>
                </View>
              ) : null}

              {/* Mensagem de Sucesso (mais clean) */}
              {successMessage ? (
                <View className="bg-green-50 border border-green-200 rounded-xl px-4 py-3 mb-4">
                  <View className="flex-row items-center">
                    <Ionicons name="checkmark-circle-outline" size={20} color="#16a34a" />
                    <Text className="text-green-700 text-sm ml-2 font-semibold flex-1">
                      {successMessage}
                    </Text>
                  </View>
                  <Text className="text-green-700/80 text-xs mt-1 ml-7">
                    A entrar...
                  </Text>
                </View>
              ) : null}

              {/* Login Button */}
              <TouchableOpacity
                testID="login-button"
                onPress={handleLogin}
                disabled={loading}
                className={`bg-blue-600 rounded-xl py-4 items-center shadow-sm ${
                  loading ? "opacity-70" : ""
                }`}
              >
                {loading ? (
                  <ActivityIndicator color="white" />
                ) : (
                  <Text className="text-white text-lg font-semibold">Entrar</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
