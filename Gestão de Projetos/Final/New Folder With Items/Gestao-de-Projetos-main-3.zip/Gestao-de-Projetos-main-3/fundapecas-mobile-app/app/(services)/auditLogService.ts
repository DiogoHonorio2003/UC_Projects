import { authenticatedFetch, ApiError } from "./authService";

const API_URL = process.env.EXPO_PUBLIC_API_URL;

export type AuditLog = {
  id: number;
  userId: number | null;
  action: string;
  entity: string;
  entityId: string | null;
  details?: any;
  timestamp: string;
  user?: {
    id: number;
    username: string;
    fullName?: string;
    role?: string;
  };
};

export type PaginatedAuditLogsResponse = {
  items: AuditLog[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
};

export type GetAuditLogsParams = {
  page?: number;
  pageSize?: number;
  userId?: number;
  action?: string;
  entity?: string;
  entityId?: string;
  search?: string;
  dateFrom?: string; // ISO
  dateTo?: string; // ISO
};

const parseApiError = async (res: Response): Promise<ApiError & { details?: any }> => {
  const text = await res.text();

  try {
    const json = JSON.parse(text);

    const details =
      json?.details ??
      json?.errors ?? // <- controller devolve { errors: error.errors }
      json?.issues ??
      json?.validation ??
      json?.error?.details ??
      json?.error?.errors;

    return {
      message: json?.message || "Erro na API",
      statusCode: res.status,
      ...(details ? { details } : {}),
    };
  } catch {
    return {
      message: text || "Erro na API",
      statusCode: res.status,
    };
  }
};

const toQueryString = (params: Record<string, any>) => {
  const usp = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v === undefined || v === null || v === "") return;
    usp.append(k, String(v));
  });
  const qs = usp.toString();
  return qs ? `?${qs}` : "";
};

export const getAuditLogs = async (
  params?: GetAuditLogsParams
): Promise<PaginatedAuditLogsResponse> => {
  const page = params?.page ?? 1;
  const pageSize = params?.pageSize ?? 20;

  const qs = toQueryString({
    page,
    pageSize,
    userId: params?.userId,
    action: params?.action,
    entity: params?.entity,
    entityId: params?.entityId,
    search: params?.search,
    dateFrom: params?.dateFrom,
    dateTo: params?.dateTo,
  });

  const res = await authenticatedFetch(`${API_URL}/audit-logs${qs}`, {
    method: "GET",
  });

  if (!res.ok) throw await parseApiError(res);

  const json = await res.json();

  if (json && Array.isArray(json.items)) {
    return {
      items: json.items as AuditLog[],
      total: Number(json.total ?? 0),
      page: Number(json.page ?? page),
      pageSize: Number(json.pageSize ?? pageSize),
      totalPages: Number(json.totalPages ?? 1),
    };
  }

  if (Array.isArray(json)) {
    const items = json as AuditLog[];
    const total = items.length;
    return {
      items,
      total,
      page,
      pageSize,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
    };
  }

  return {
    items: [],
    total: 0,
    page,
    pageSize,
    totalPages: 1,
  };
};

export const getAuditLogById = async (id: number): Promise<AuditLog> => {
  const res = await authenticatedFetch(`${API_URL}/audit-logs/${id}`, {
    method: "GET",
  });

  if (!res.ok) throw await parseApiError(res);

  return (await res.json()) as AuditLog;
};
