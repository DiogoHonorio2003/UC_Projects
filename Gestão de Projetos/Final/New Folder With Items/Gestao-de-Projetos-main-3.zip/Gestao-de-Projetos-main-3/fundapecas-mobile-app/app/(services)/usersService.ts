// app/(services)/usersService.ts
import { ApiError, authenticatedFetch } from "./authService";

const RAW_API_URL = process.env.EXPO_PUBLIC_API_URL;
const API_URL = (RAW_API_URL || "").replace(/\/+$/, "");

export type UserRole = "ADMIN" | "SALES" | "WAREHOUSE" | "CLIENT";

export type RegisterBody = {
  username: string;
  email?: string;
  fullName: string;
  password: string;
  role: UserRole;
};

export type RegisterResponse = {
  id: number;
  username: string;
  email?: string | null;
  fullName: string;
  role: UserRole;
};

export type ResetPasswordBody = {
  userId: number;
  newPassword: string;
};

export type UserSummary = {
  id: number;
  username: string;
  email?: string | null;
  fullName: string;
  role: UserRole;
  isActive: boolean;
  createdAt?: string;
  updatedAt?: string;
};

export type UpdateUserBody = Partial<{
  username: string;
  email: string | null; // permitir limpar email
  fullName: string;
  role: UserRole;
}>;

function ensureApiUrl() {
  if (!API_URL) {
    throw {
      message: "EXPO_PUBLIC_API_URL não definido. Verifica o .env do Expo.",
      statusCode: 500,
    } as ApiError;
  }
}

async function parseApiError(res: Response): Promise<ApiError> {
  const text = await res.text();

  try {
    const json = JSON.parse(text);

    const issues = json?.issues || json?.errors || json?.details?.issues || json?.details?.errors;
    if (Array.isArray(issues) && issues.length > 0) {
      const msg = issues
        .map((i: any) => {
          const path = Array.isArray(i.path) ? i.path.join(".") : "";
          const m = i.message || "inválido";
          return path ? `${path}: ${m}` : m;
        })
        .join(" | ");
      return { message: msg || json?.message || "Erro na API", statusCode: res.status };
    }

    return { message: json?.message || text || `HTTP ${res.status}`, statusCode: res.status };
  } catch {
    return { message: text || `HTTP ${res.status}`, statusCode: res.status };
  }
}

/**
 * Wrapper para garantir:
 * - API_URL definido
 * - usa o authenticatedFetch (que deve acrescentar Bearer token e fazer refresh se necessário)
 * - converte erros num ApiError consistente
 */
async function authedRequest(url: string, init?: RequestInit): Promise<Response> {
  ensureApiUrl();

  // Garante Content-Type quando há body JSON
  const hasBody = typeof init?.body !== "undefined" && init?.body !== null;
  const headers: Record<string, string> = {
    ...(init?.headers as Record<string, string> | undefined),
  };

  if (hasBody && !headers["Content-Type"]) {
    headers["Content-Type"] = "application/json";
  }

  const res = await authenticatedFetch(url, { ...(init || {}), headers });
  return res;
}

export async function getUsers(params?: { role?: UserRole; isActive?: boolean }): Promise<UserSummary[]> {
  const qs = new URLSearchParams();
  if (params?.role) qs.set("role", params.role);
  if (typeof params?.isActive === "boolean") qs.set("isActive", String(params.isActive));

  const url = `${API_URL}/users${qs.toString() ? `?${qs.toString()}` : ""}`;

  const res = await authedRequest(url, { method: "GET" });
  if (!res.ok) throw await parseApiError(res);

  return (await res.json()) as UserSummary[];
}

export async function registerUser(body: RegisterBody): Promise<RegisterResponse> {
  const res = await authedRequest(`${API_URL}/auth/register`, {
    method: "POST",
    body: JSON.stringify(body),
  });

  if (!res.ok) throw await parseApiError(res);
  return (await res.json()) as RegisterResponse;
}

export async function adminResetPassword(
  body: ResetPasswordBody
): Promise<{ message: string; userId: number }> {
  const payload = { userId: Number(body.userId), newPassword: body.newPassword };

  const res = await authedRequest(`${API_URL}/auth/admin/reset-password`, {
    method: "POST",
    body: JSON.stringify(payload),
  });

  if (!res.ok) throw await parseApiError(res);
  return (await res.json()) as { message: string; userId: number };
}

export async function updateUser(userId: number, body: UpdateUserBody): Promise<UserSummary> {
  const res = await authedRequest(`${API_URL}/users/${userId}`, {
    method: "PUT",
    body: JSON.stringify(body),
  });

  if (!res.ok) throw await parseApiError(res);
  return (await res.json()) as UserSummary;
}

export async function activateUser(userId: number): Promise<UserSummary> {
  const res = await authedRequest(`${API_URL}/users/${userId}/activate`, {
    method: "PUT",
  });

  if (!res.ok) throw await parseApiError(res);
  return (await res.json()) as UserSummary;
}

export async function deactivateUser(userId: number): Promise<UserSummary> {
  const res = await authedRequest(`${API_URL}/users/${userId}/deactivate`, {
    method: "PUT",
  });

  if (!res.ok) throw await parseApiError(res);
  return (await res.json()) as UserSummary;
}
