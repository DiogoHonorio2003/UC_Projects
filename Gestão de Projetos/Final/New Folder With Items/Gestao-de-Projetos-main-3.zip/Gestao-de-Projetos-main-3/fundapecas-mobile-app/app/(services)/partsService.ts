import { authenticatedFetch, ApiError } from './authService';
export type { ApiError };

// Configuração da API
const API_URL = process.env.EXPO_PUBLIC_API_URL;

// Função helper para construir URLs absolutas de imagens
const getImageUrl = (relativePath: string): string => {
    if (!relativePath) {
        return '';
    }
    
    // Se já for uma URL absoluta, retorna como está
    if (relativePath.startsWith('http://') || relativePath.startsWith('https://')) {
        return relativePath;
    }
    
    // Remove barra inicial se existir
    const cleanPath = relativePath.startsWith('/') ? relativePath.slice(1) : relativePath;
    
    // Constrói a URL absoluta
    const fullUrl = `${API_URL}/${cleanPath}`;
    
    return fullUrl;
};

export interface Category {
    id: number;
    name: string;
}

export interface Location {
    id: number;
    fullCode: string;
    shelf: string;
    position: string;
    capacity: number;
    _count: {
        parts: number;
    };
}

export interface PartImage {
    id: number;
    url: string;
    partId: number;
}

export interface Specification {
    id: number;
    name: string;
}

export interface PartSpecification {
    id: number;
    specId: number;
    value: string;
    spec: Specification;
}

export interface SubReference {
    id: number;
    value: string;
    partId: number;
}

export type PartCondition = 'NEW' | 'USED' | 'REFURBISHED';

export interface Part {
    id: number;
    name: string;
    refInternal: string;
    refOEM?: string | null;
    description?: string | null;
    price: number;
    condition: PartCondition;
    categoryId: number;
    locationId: number;
    createdAt: string;
    updatedAt: string;
    category: Category;
    location: Location;
    images: PartImage[];
    specifications: PartSpecification[];
    subReferences?: SubReference[];
}

export interface SearchPartsResponse {
    items: Part[];
    total: number;
    page: number;
    pageSize: number;
    totalPages: number;
}

export interface PaginatedParts {
    parts: Part[];
    currentPage: number;
    totalPages: number;
    totalItems: number;
    itemsPerPage: number;
}

export interface CreatePartData {
    name: string;
    refInternal: string;
    refOEM?: string | null;
    description?: string | null;
    price: number;
    condition: PartCondition;
    categoryId: number;
    locationId: number;
    specifications?: { specId: number; value: string }[];
    subReferences?: string[];
}

export interface SearchPartsParams {
    text?: string;
    categoryId?: number;
    condition?: PartCondition;
    priceMin?: number;
    priceMax?: number;
    locationId?: number;
    isVisible?: boolean;
    page?: number;
    pageSize?: number;
    sortBy?: 'name' | 'price' | 'createdAt' | 'updatedAt' | 'refInternal';
    sortOrder?: 'asc' | 'desc';
}

// Função helper para processar as imagens de uma peça
const processPartImages = (part: Part): Part => {
    if (part.images && part.images.length > 0) {
        const processedImages = part.images.map(img => ({
            ...img,
            url: getImageUrl(img.url)
        }));
        
        return {
            ...part,
            images: processedImages
        };
    }
    
    return part;
};

export const deletePart = async (ref: string): Promise<void> => {
    try {
        const response = await authenticatedFetch(`${API_URL}/parts/${ref}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            if (response.status === 404) {
                throw {
                    message: 'Peça não encontrada',
                    statusCode: 404,
                } as ApiError;
            }

            if (response.status === 403) {
                throw {
                    message: 'Não tem permissão para eliminar peças',
                    statusCode: 403,
                } as ApiError;
            }
            
            throw {
                message: 'Erro ao eliminar peça',
                statusCode: response.status,
            } as ApiError;
        }
    } catch (error) {
        if ((error as ApiError).message) {
            throw error;
        }
        
        throw {
            message: 'Erro de conexão',
            statusCode: 0,
        } as ApiError;
    }
};

// ==================== PARTS ====================

export const getPartById = async (id: string | number): Promise<Part> => {
    try {
        const response = await authenticatedFetch(`${API_URL}/parts/${id}`, {
            method: 'GET',
        });

        if (!response.ok) {
            if (response.status === 404) {
                throw {
                    message: 'Peça não encontrada',
                    statusCode: 404,
                } as ApiError;
            }

            throw {
                message: 'Erro ao carregar peça',
                statusCode: response.status,
            } as ApiError;
        }

        const data = await response.json();

        // Processa as URLs das imagens
        return processPartImages(data);
    } catch (error) {
        if ((error as ApiError).message) {
            throw error;
        }

        throw {
            message: 'Erro de conexão. Verifique se o backend está rodando.',
            statusCode: 0,
        } as ApiError;
    }
};

export const searchParts = async (params: SearchPartsParams = {}): Promise<SearchPartsResponse> => {
    try {
        // Construir query string
        const queryParams = new URLSearchParams();
        
        if (params.text) queryParams.append('text', params.text);
        if (params.categoryId) queryParams.append('categoryId', params.categoryId.toString());
        if (params.condition) queryParams.append('condition', params.condition);
        if (params.priceMin !== undefined) queryParams.append('priceMin', params.priceMin.toString());
        if (params.priceMax !== undefined) queryParams.append('priceMax', params.priceMax.toString());
        if (params.locationId) queryParams.append('locationId', params.locationId.toString());
        if (params.isVisible !== undefined) queryParams.append('isVisible', params.isVisible.toString());
        if (params.page) queryParams.append('page', params.page.toString());
        if (params.pageSize) queryParams.append('pageSize', params.pageSize.toString());
        if (params.sortBy) queryParams.append('sortBy', params.sortBy);
        if (params.sortOrder) queryParams.append('sortOrder', params.sortOrder);

        const url = `${API_URL}/parts/search?${queryParams.toString()}`;

        const response = await authenticatedFetch(url, {
            method: 'GET',
        });

        if (!response.ok) {
            throw {
                message: 'Erro ao pesquisar peças',
                statusCode: response.status,
            } as ApiError;
        }

        const data = await response.json();

        // Processa as URLs das imagens de todas as peças
        const processedItems = data.items.map((part: Part) => processPartImages(part));

        return {
            ...data,
            items: processedItems,
        };
    } catch (error) {
        if ((error as ApiError).message) {
            throw error;
        }

        throw {
            message: 'Erro de conexão',
            statusCode: 0,
        } as ApiError;
    }
};

export const createPart = async (data: CreatePartData): Promise<Part> => {
    try {
        const response = await authenticatedFetch(`${API_URL}/parts`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => null);
            
            if (response.status === 409) {
                throw {
                    message: errorData?.message || 'Referência interna já existe',
                    statusCode: 409,
                } as ApiError;
            }

            if (response.status === 400) {
                throw {
                    message: errorData?.message || 'Dados inválidos',
                    statusCode: 400,
                } as ApiError;
            }
            
            throw {
                message: errorData?.message || 'Erro ao criar peça',
                statusCode: response.status,
            } as ApiError;
        }

        const part = await response.json();
        
        return processPartImages(part);
    } catch (error) {
        if ((error as ApiError).message) {
            throw error;
        }
        
        throw {
            message: 'Erro de conexão. Verifique se o backend está rodando.',
            statusCode: 0,
        } as ApiError;
    }
};


// ==================== WHATSAPP ====================

export const getWhatsappReservationLink = async (ref: string): Promise<string> => {
    try {
        const response = await authenticatedFetch(`${API_URL}/parts/${ref}/whatsapp-link`, {
            method: 'GET',
        });

        if (!response.ok) {
            if (response.status === 404) {
                throw {
                    message: 'Peça não encontrada',
                    statusCode: 404,
                } as ApiError;
            }
            
            throw {
                message: 'Erro ao gerar link WhatsApp',
                statusCode: response.status,
            } as ApiError;
        }

        const data = await response.json();
        
        return data.url;
    } catch (error) {
        if ((error as ApiError).message) {
            throw error;
        }
        
        throw {
            message: 'Erro de conexão',
            statusCode: 0,
        } as ApiError;
    }
};

// ==================== CATEGORIES ====================

export const getCategories = async (): Promise<Category[]> => {
    try {
        const response = await authenticatedFetch(`${API_URL}/parts/categories/list`, {
            method: 'GET',
        });

        if (!response.ok) {
            if (response.status === 404) {
                throw {
                    message: 'Endpoint de categorias não encontrado. Verifique a rota no backend.',
                    statusCode: 404,
                } as ApiError;
            }
            
            throw {
                message: `Erro ao carregar categorias (${response.status})`,
                statusCode: response.status,
            } as ApiError;
        }

        const data = await response.json();
        
        return data;
    } catch (error) {
        if ((error as ApiError).message) {
            throw error;
        }
        
        throw {
            message: 'Erro de conexão. Verifique se o backend está rodando.',
            statusCode: 0,
        } as ApiError;
    }
};

// ==================== LOCATIONS ====================

export const getLocations = async (): Promise<Location[]> => {
    try {
        const response = await authenticatedFetch(`${API_URL}/parts/locations/list`, {
            method: 'GET',
        });

        if (!response.ok) {
            if (response.status === 404) {
                throw {
                    message: 'Endpoint de localizações não encontrado. Verifique a rota no backend.',
                    statusCode: 404,
                } as ApiError;
            }
            
            throw {
                message: `Erro ao carregar localizações (${response.status})`,
                statusCode: response.status,
            } as ApiError;
        }

        const data = await response.json();
        
        return data;
    } catch (error) {
        if ((error as ApiError).message) {
            throw error;
        }
        
        throw {
            message: 'Erro de conexão',
            statusCode: 0,
        } as ApiError;
    }
};

// ==================== SPECIFICATIONS ====================

export const getSpecifications = async (): Promise<Specification[]> => {
    try {
        const response = await authenticatedFetch(`${API_URL}/parts/specifications/list`, {
            method: 'GET',
        });

        if (!response.ok) {
            if (response.status === 404) {
                throw {
                    message: 'Endpoint de especificações não encontrado. Verifique a rota no backend.',
                    statusCode: 404,
                } as ApiError;
            }
            
            throw {
                message: `Erro ao carregar especificações (${response.status})`,
                statusCode: response.status,
            } as ApiError;
        }

        const data = await response.json();
        
        return data;
    } catch (error) {
        if ((error as ApiError).message) {
            throw error;
        }
        
        throw {
            message: 'Erro de conexão',
            statusCode: 0,
        } as ApiError;
    }
};

// ==================== UTILITY FUNCTIONS ====================

export const paginateParts = (
    parts: Part[],
    searchQuery: string = '',
    page: number = 1,
    itemsPerPage: number = 20
): PaginatedParts => {
    // Filtrar peças baseado na pesquisa
    const filteredParts = searchQuery.trim() === '' 
        ? parts 
        : parts.filter(part => 
            part.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            part.refInternal.toLowerCase().includes(searchQuery.toLowerCase()) ||
            part.refOEM?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            part.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            part.category.name.toLowerCase().includes(searchQuery.toLowerCase())
        );

    const totalItems = filteredParts.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const startIndex = (page - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const paginatedParts = filteredParts.slice(startIndex, endIndex);

    return {
        parts: paginatedParts,
        currentPage: page,
        totalPages,
        totalItems,
        itemsPerPage,
    };
};

export const getConditionName = (condition: string): string => {
    const conditions: Record<string, string> = {
        NEW: 'Nova',
        USED: 'Usada',
        REFURBISHED: 'Recondicionada',
    };
    return conditions[condition] || condition;
};

export const formatPrice = (price: number): string => {
    return new Intl.NumberFormat('pt-PT', {
        style: 'currency',
        currency: 'EUR',
    }).format(price);
};

export const formatDate = (dateString: string): string => {
    try {
        return new Date(dateString).toLocaleDateString('pt-PT', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
        });
    } catch (error) {
        return 'Data inválida';
    }
};