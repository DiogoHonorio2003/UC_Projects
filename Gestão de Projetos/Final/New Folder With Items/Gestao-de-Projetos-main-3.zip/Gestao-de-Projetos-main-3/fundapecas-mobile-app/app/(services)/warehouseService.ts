import { authenticatedFetch, ApiError } from './authService';

const API_URL = process.env.EXPO_PUBLIC_API_URL;

export interface Warehouse {
    id: number;
    code: string;
    name: string;
    locationCount: number;
    createdAt: string;
    updatedAt: string;
}

export interface WarehouseLocation {
    id: number;
    warehouseId: number;
    rack: string;
    shelf: string;
    pallet: string | null;
    fullCode: string;
    capacity: number;
    used: number;
    availableSlots: number;
    isAvailable: boolean;
}

// ==================== WAREHOUSES ====================

export const getWarehouses = async (): Promise<Warehouse[]> => {
    try {
        console.log('🏭 Carregando warehouses...');
        console.log('🔗 URL:', `${API_URL}/warehouses`);

        const response = await authenticatedFetch(`${API_URL}/warehouses`, {
            method: 'GET',
        });

        console.log('📡 Status da resposta:', response.status);

        if (!response.ok) {
            const errorText = await response.text();
            console.error('❌ Erro na resposta:', errorText);
            
            throw {
                message: `Erro ao carregar warehouses (${response.status})`,
                statusCode: response.status,
            } as ApiError;
        }

        const data = await response.json();
        console.log('✅ Warehouses carregados:', data.length);
        
        return data;
    } catch (error) {
        console.error('❌ Erro completo:', error);
        
        if ((error as ApiError).message) {
            throw error;
        }
        
        throw {
            message: 'Erro de conexão. Verifique se o backend está rodando.',
            statusCode: 0,
        } as ApiError;
    }
};

export const getWarehouseLocations = async (warehouseId: number): Promise<WarehouseLocation[]> => {
    try {
        console.log(`📦 Carregando localizações do warehouse ${warehouseId}...`);
        console.log('🔗 URL:', `${API_URL}/warehouses/${warehouseId}/locations`);

        const response = await authenticatedFetch(`${API_URL}/warehouses/${warehouseId}/locations`, {
            method: 'GET',
        });

        console.log('📡 Status da resposta:', response.status);

        if (!response.ok) {
            const errorText = await response.text();
            console.error('❌ Erro na resposta:', errorText);
            
            if (response.status === 404) {
                throw {
                    message: 'Warehouse não encontrado.',
                    statusCode: 404,
                } as ApiError;
            }
            
            throw {
                message: `Erro ao carregar localizações (${response.status})`,
                statusCode: response.status,
            } as ApiError;
        }

        const data = await response.json();
        console.log('✅ Localizações carregadas:', data.length);
        
        return data;
    } catch (error) {
        console.error('❌ Erro completo:', error);
        
        if ((error as ApiError).message) {
            throw error;
        }
        
        throw {
            message: 'Erro de conexão',
            statusCode: 0,
        } as ApiError;
    }
};