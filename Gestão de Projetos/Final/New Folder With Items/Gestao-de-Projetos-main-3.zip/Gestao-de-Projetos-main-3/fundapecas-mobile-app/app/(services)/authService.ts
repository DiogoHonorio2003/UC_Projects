import AsyncStorage from "@react-native-async-storage/async-storage";

// Configuração da API
const API_URL = process.env.EXPO_PUBLIC_API_URL;

// Flag para evitar múltiplos refreshes simultâneos
let isRefreshing = false;
let refreshPromise: Promise<string | null> | null = null;

// ============================================
// TIPOS E INTERFACES
// ============================================

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface LoginResponse {
  accessToken: string;
  refreshToken: string;
  user?: {
    id: number;
    username: string;
    email: string;
    fullName: string;
    role: string;
  };
}

export interface ApiError {
  message: string;
  statusCode?: number;
}

export interface MeResponse {
  id: number;
  username: string;
  email?: string | null;
  fullName: string;
  role: string; // "ADMIN" | "SALES" | "WAREHOUSE" | "CLIENT"
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

// ============================================
// VALIDAÇÕES
// ============================================

export const validateLoginFields = (
  username: string,
  password: string
): { valid: boolean; message?: string } => {
  if (!username || !password) {
    return {
      valid: false,
      message: "Preenche todos os campos.",
    };
  }

  if (username.length < 3) {
    return {
      valid: false,
      message: "Username deve ter pelo menos 3 caracteres.",
    };
  }

  return { valid: true };
};

// ============================================
// SERVIÇO DE AUTENTICAÇÃO
// ============================================

/**
 * Realiza o login do utilizador
 * @param credentials - Username e password
 * @returns LoginResponse com tokens e dados do utilizador
 * @throws ApiError se houver erro no login
 */
export const login = async (
  credentials: LoginCredentials
): Promise<LoginResponse> => {
  try {
    console.log("🔐 Tentando fazer login...");

    const response = await fetch(`${API_URL}/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(credentials),
    });

    // Tenta ler o corpo da resposta como texto primeiro
    const responseText = await response.text();

    if (!response.ok) {
      // Tenta fazer parse como JSON
      let errorData;
      try {
        errorData = JSON.parse(responseText);
      } catch {
        // Se não for JSON, usa o texto direto
        console.error("❌ Resposta não-JSON:", responseText);

        // Verifica se é rate limiting
        if (responseText.toLowerCase().includes("too many")) {
          throw {
            message: "Demasiadas tentativas. Aguarda alguns minutos.",
            statusCode: 429,
          } as ApiError;
        }

        throw {
          message: responseText || "Erro ao fazer login",
          statusCode: response.status,
        } as ApiError;
      }

      // Se conseguiu fazer parse do JSON
      throw {
        message: errorData.message || "Credenciais inválidas",
        statusCode: response.status,
      } as ApiError;
    }

    // Parse do JSON de sucesso
    const data = JSON.parse(responseText);

    // Guarda o token no AsyncStorage
    if (data.accessToken) {
      await AsyncStorage.setItem("userToken", data.accessToken);
      console.log("✅ Token guardado com sucesso");
    }

    // Guarda o refresh token
    if (data.refreshToken) {
      await AsyncStorage.setItem("refreshToken", data.refreshToken);
      console.log("✅ Refresh token guardado com sucesso");
    }

    console.log("✅ Login bem-sucedido");
    return data;
  } catch (error) {
    // Se já é um ApiError, re-throw
    if ((error as ApiError).message) {
      throw error;
    }

    // Erro de rede/conexão
    console.error("❌ Erro de conexão:", error);
    throw {
      message: "Erro de conexão. Verifica se o backend está ativo.",
      statusCode: 0,
    } as ApiError;
  }
};

/**
 * Faz logout do utilizador
 */
export const logout = async (): Promise<void> => {
  try {
    await AsyncStorage.multiRemove(["userToken", "refreshToken"]);
    console.log("✅ Logout bem-sucedido");
  } catch (error) {
    console.error("❌ Erro ao fazer logout:", error);
  }
};

/**
 * Verifica se o utilizador está autenticado
 */
export const isAuthenticated = async (): Promise<boolean> => {
  try {
    const token = await AsyncStorage.getItem("userToken");
    return !!token;
  } catch (error) {
    console.error("❌ Erro ao verificar autenticação:", error);
    return false;
  }
};

/**
 * Obtém o token guardado
 */
export const getToken = async (): Promise<string | null> => {
  try {
    return await AsyncStorage.getItem("userToken");
  } catch (error) {
    console.error("❌ Erro ao obter token:", error);
    return null;
  }
};

/**
 * Obtém o refresh token guardado
 */
export const getRefreshToken = async (): Promise<string | null> => {
  try {
    return await AsyncStorage.getItem("refreshToken");
  } catch (error) {
    console.error("❌ Erro ao obter refresh token:", error);
    return null;
  }
};

/**
 * Renova os tokens usando o refresh token
 * @returns Novo access token ou null se falhar
 */
export const refreshTokens = async (): Promise<string | null> => {
  // Evita múltiplos refreshes simultâneos
  if (isRefreshing && refreshPromise) {
    console.log("🔄 Refresh já em andamento, aguardando...");
    return refreshPromise;
  }

  isRefreshing = true;

  refreshPromise = (async () => {
    try {
      const refreshToken = await getRefreshToken();

      if (!refreshToken) {
        console.log("❌ Refresh token não encontrado");
        return null;
      }

      console.log("🔄 Renovando tokens...");

      const response = await fetch(`${API_URL}/auth/refresh`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ refreshToken }),
      });

      if (!response.ok) {
        console.log("❌ Refresh falhou, sessão expirada");
        // Limpa os tokens inválidos
        await AsyncStorage.multiRemove(["userToken", "refreshToken"]);
        return null;
      }

      const data = await response.json();

      // Guarda os novos tokens
      if (data.accessToken) {
        await AsyncStorage.setItem("userToken", data.accessToken);
        console.log("✅ Novo access token guardado");
      }

      if (data.refreshToken) {
        await AsyncStorage.setItem("refreshToken", data.refreshToken);
        console.log("✅ Novo refresh token guardado");
      }

      return data.accessToken;
    } catch (error) {
      console.error("❌ Erro ao renovar tokens:", error);
      return null;
    } finally {
      isRefreshing = false;
      refreshPromise = null;
    }
  })();

  return refreshPromise;
};

/**
 * Faz uma requisição autenticada com refresh automático
 * Se o access token expirar, tenta renovar automaticamente
 */
export const authenticatedFetch = async (
  url: string,
  options: RequestInit = {}
): Promise<Response> => {
  let token = await getToken();

  if (!token) {
    throw { message: "Não autenticado", statusCode: 401 } as ApiError;
  }

  // Primeira tentativa
  const response = await fetch(url, {
    ...options,
    headers: {
      ...options.headers,
      Authorization: `Bearer ${token}`,
    },
  });

  // Se 401, tenta refresh e repete a requisição
  if (response.status === 401) {
    console.log("🔄 Token expirado, tentando refresh...");
    
    const newToken = await refreshTokens();

    if (!newToken) {
      // Refresh falhou - sessão expirada
      throw { message: "Sessão expirada. Faz login novamente.", statusCode: 401 } as ApiError;
    }

    // Repete a requisição com o novo token
    console.log("🔄 Repetindo requisição com novo token...");
    return fetch(url, {
      ...options,
      headers: {
        ...options.headers,
        Authorization: `Bearer ${newToken}`,
      },
    });
  }

  return response;
};

/**
 * Obtém o perfil do utilizador autenticado (role incluída)
 * Endpoint: GET /auth/me
 * Usa refresh automático se o token expirar
 */
export const getMe = async (): Promise<MeResponse> => {
  try {
    const response = await authenticatedFetch(`${API_URL}/auth/me`, {
      method: "GET",
    });

    const responseText = await response.text();

    if (!response.ok) {
      let errorData: any = null;
      try {
        errorData = JSON.parse(responseText);
      } catch {
        // ignora
      }

      throw {
        message: errorData?.message || responseText || "Erro ao obter utilizador",
        statusCode: response.status,
      } as ApiError;
    }

    return JSON.parse(responseText) as MeResponse;
  } catch (error) {
    if ((error as ApiError).message) throw error;

    throw {
      message: "Erro ao obter utilizador. Verifica o backend/token.",
      statusCode: 0,
    } as ApiError;
  }
};
