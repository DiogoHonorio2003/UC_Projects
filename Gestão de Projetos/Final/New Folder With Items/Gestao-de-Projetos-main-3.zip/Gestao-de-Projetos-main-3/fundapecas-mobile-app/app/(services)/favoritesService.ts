import { authenticatedFetch, ApiError } from './authService';

const API_URL = process.env.EXPO_PUBLIC_API_URL;

export interface FavoriteResult {
    success: boolean;
    message: string;
}

/**
 * Obtém todos os favoritos do utilizador
 */
export const getUserFavorites = async (): Promise<any[]> => {
    try {
        const response = await authenticatedFetch(`${API_URL}/favorites`, {
            method: 'GET',
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw { 
                message: errorData.message || 'Erro ao carregar favoritos', 
                statusCode: response.status 
            } as ApiError;
        }

        return await response.json();
    } catch (error: any) {
        if (error.message && error.statusCode) {
            throw error as ApiError;
        }
        throw { 
            message: 'Erro de conexão ao carregar favoritos', 
            statusCode: 500 
        } as ApiError;
    }
};

/**
 * Adiciona uma peça aos favoritos
 */
export const addFavorite = async (partId: number): Promise<void> => {
    try {
        const response = await authenticatedFetch(`${API_URL}/favorites/${partId}`, {
            method: 'POST',
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw { 
                message: errorData.message || 'Erro ao adicionar favorito', 
                statusCode: response.status 
            } as ApiError;
        }
    } catch (error: any) {
        if (error.message && error.statusCode) {
            throw error as ApiError;
        }
        throw { 
            message: 'Erro de conexão ao adicionar favorito', 
            statusCode: 500 
        } as ApiError;
    }
};

/**
 * Remove uma peça dos favoritos
 */
export const removeFavorite = async (partId: number): Promise<void> => {
    try {
        const response = await authenticatedFetch(`${API_URL}/favorites/${partId}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw { 
                message: errorData.message || 'Erro ao remover favorito', 
                statusCode: response.status 
            } as ApiError;
        }
    } catch (error: any) {
        if (error.message && error.statusCode) {
            throw error as ApiError;
        }
        throw { 
            message: 'Erro de conexão ao remover favorito', 
            statusCode: 500 
        } as ApiError;
    }
};

/**
 * Verifica se uma peça está nos favoritos
 */
export const checkFavorite = async (partId: number): Promise<boolean> => {
    try {
        const response = await authenticatedFetch(`${API_URL}/favorites/${partId}/check`, {
            method: 'GET',
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw { 
                message: errorData.message || 'Erro ao verificar favorito', 
                statusCode: response.status 
            } as ApiError;
        }

        const data = await response.json();
        return data.isFavorite;
    } catch (error: any) {
        if (error.message && error.statusCode) {
            throw error as ApiError;
        }
        throw { 
            message: 'Erro de conexão ao verificar favorito', 
            statusCode: 500 
        } as ApiError;
    }
};

export { ApiError };
