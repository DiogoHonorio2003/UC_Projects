import React, { useState, useEffect, useCallback } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    ActivityIndicator,
    TouchableOpacity,
    Animated,
    Modal,
    TextInput,
    Linking,
    Keyboard,
    TouchableWithoutFeedback,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useFocusEffect } from '@react-navigation/native';
import Header from '../../(shared)/Header';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
    getPartById,
    deletePart,
    formatPrice,
    getConditionName,
    Part,
    ApiError,
    getWhatsappReservationLink,
} from '../../(services)/partsService';
import {
    checkFavorite,
    addFavorite,
    removeFavorite,
} from '../../(services)/favoritesService';
import {
    createReservation,
    CreateReservationData,
} from '../../(services)/reservationsService';
import { getMe } from '../../(services)/authService';

const PartDetails = () => {
    const router = useRouter();
    const { id } = useLocalSearchParams();
    const [part, setPart] = useState<Part | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [selectedImageIndex, setSelectedImageIndex] = useState(0);
    const [isFavorite, setIsFavorite] = useState(false);
    const [favoriteLoading, setFavoriteLoading] = useState(false);
    const [deleteModalVisible, setDeleteModalVisible] = useState(false);
    const [deleteLoading, setDeleteLoading] = useState(false);
    const [orderModalVisible, setOrderModalVisible] = useState(false);
    const [orderNotes, setOrderNotes] = useState('');
    const [orderLoading, setOrderLoading] = useState(false);
    const [whatsappLoading, setWhatsappLoading] = useState(false);
    const [showSuccessMessage, setShowSuccessMessage] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const [showErrorMessage, setShowErrorMessage] = useState(false);
    const [errorMessageText, setErrorMessageText] = useState('');
    const fadeAnim = useState(new Animated.Value(0))[0];

    const [userRole, setUserRole] = useState<string | null>(null);

    // Carregar role do utilizador
    useEffect(() => {
        (async () => {
            try {
                const me = await getMe();
                setUserRole(me.role);
            } catch {
                setUserRole(null);
            }
        })();
    }, []);

    // Recarregar dados sempre que a tela é focada
    useFocusEffect(
        useCallback(() => {
            loadPartDetails();
        }, [id])
    );

    useEffect(() => {
        if (part?.id) {
            loadFavoriteStatus();
        }
    }, [part]);

    const loadPartDetails = async () => {
        try {
            setLoading(true);
            setError(null);
            
            const partId = Array.isArray(id) ? id[0] : id;
            
            if (!partId) {
                setError('ID da peça não encontrado');
                setLoading(false);
                return;
            }
            
            const partData = await getPartById(partId);
            setPart(partData);
        } catch (err) {
            const apiError = err as ApiError;
            setError(apiError.message);
        } finally {
            setLoading(false);
        }
    };

    const loadFavoriteStatus = async () => {
        try {
            if (!part?.id) return;
            const status = await checkFavorite(part.id);
            setIsFavorite(status);
        } catch (err) {
            
        }
    };

    const showMessage = (message: string, isSuccess: boolean) => {
        if (isSuccess) {
            setSuccessMessage(message);
            setShowSuccessMessage(true);
        } else {
            setErrorMessageText(message);
            setShowErrorMessage(true);
        }

        fadeAnim.setValue(0);
        Animated.sequence([
            Animated.timing(fadeAnim, {
                toValue: 1,
                duration: 300,
                useNativeDriver: true,
            }),
            Animated.delay(2500),
            Animated.timing(fadeAnim, {
                toValue: 0,
                duration: 300,
                useNativeDriver: true,
            }),
        ]).start(() => {
            if (isSuccess) {
                setShowSuccessMessage(false);
            } else {
                setShowErrorMessage(false);
            }
        });
    };

    const handleToggleFavorite = async () => {
        if (!part) return;

        try {
            setFavoriteLoading(true);
            
            if (isFavorite) {
                await removeFavorite(part.id);
                setIsFavorite(false);
            } else {
                await addFavorite(part.id);
                setIsFavorite(true);
            }
        } catch (err) {
            const apiError = err as ApiError;
            showMessage(apiError.message, false);
        } finally {
            setFavoriteLoading(false);
        }
    };

    const handleOpenOrderModal = () => {
        setOrderModalVisible(true);
        setOrderNotes('');
    };

    const handleCreateOrder = async () => {
        if (!part) return;

        Keyboard.dismiss();

        try {
            setOrderLoading(true);

            const data: CreateReservationData = {
                partId: part.id,
                notes: orderNotes.trim() || undefined,
            };

            await createReservation(data);
            showMessage('Pedido criado com sucesso!', true);
            setOrderModalVisible(false);
            setOrderNotes('');
        } catch (err) {
            const apiError = err as ApiError;
            showMessage(apiError.message || 'Já existe um pedido em aberto para esta peça.', false);
        } finally {
            setOrderLoading(false);
        }
    };

    const handleWhatsappReservation = async () => {
        if (!part) return;

        try {
            setWhatsappLoading(true);
            
            const whatsappUrl = await getWhatsappReservationLink(part.refInternal);
            
            const canOpen = await Linking.canOpenURL(whatsappUrl);
            
            if (canOpen) {
                await Linking.openURL(whatsappUrl);
            }
        } catch (err) {
            const apiError = err as ApiError;
            console.error('Erro ao abrir WhatsApp:', apiError.message);
        } finally {
            setWhatsappLoading(false);
        }
    };

    const handleDelete = async () => {
        if (!part) return;

        setDeleteModalVisible(false);

        try {
            setDeleteLoading(true);
            await deletePart(part.refInternal);
            showMessage('Peça eliminada com sucesso', true);
            setTimeout(() => {
                router.replace('/parts');
            }, 1500);
        } catch (err) {
            const apiError = err as ApiError;
            showMessage(apiError.message, false);
        } finally {
            setDeleteLoading(false);
        }
    };

    const handleBack = () => {
        router.replace('/parts');
    };

    const handleEdit = () => {
        const partId = Array.isArray(id) ? id[0] : id;
        router.push(`/Parts/editPart?id=${partId}`);
    };

    const handleLogoutPress = async () => {
        try {
            await AsyncStorage.removeItem('userToken');
            router.replace('/login');
        } catch (error) {
            console.error('Erro ao fazer logout:', error);
        }
    };

    const handleProfilePress = () => {
        router.push('/profile');
    };

    const handleMovement = () => {
        const partId = Array.isArray(id) ? id[0] : id;
        router.push(`/Parts/movementPart?id=${partId}`);
    };

    // Definir permissões por role
    const isAdmin = userRole === 'ADMIN';
    const isWarehouse = userRole === 'WAREHOUSE';
    const isSales = userRole === 'SALES';
    const isClient = userRole === 'CLIENT';

    // Permissões de botões
    const canDelete = isAdmin;
    const canEdit = isAdmin || isWarehouse || isSales;
    const canMovement = isAdmin || isWarehouse;
    const canOrder = isAdmin || isSales;
    const canFavorite = true;
    const canWhatsapp = true;

    if (loading) {
        return (
            <SafeAreaView style={styles.container}>
                <View style={styles.centerContainer}>
                    <ActivityIndicator size="large" color="#3b82f6" />
                    <Text style={styles.loadingText}>Carregando detalhes...</Text>
                </View>
            </SafeAreaView>
        );
    }

    if (error || !part) {
        return (
            <SafeAreaView style={styles.container}>
                <View style={styles.centerContainer}>
                    <Ionicons name="alert-circle-outline" size={64} color="#ef4444" />
                    <Text style={styles.errorText}>{error || 'Peça não encontrada'}</Text>
                    <TouchableOpacity style={styles.retryButton} onPress={loadPartDetails}>
                        <Text style={styles.retryButtonText}>Tentar novamente</Text>
                    </TouchableOpacity>
                </View>
            </SafeAreaView>
        );
    }

    return (
        <SafeAreaView style={styles.container}>
            <Header onProfilePress={handleProfilePress} onLogoutPress={handleLogoutPress} />
            
            {/* Mensagens de Sucesso/Erro */}
            {showSuccessMessage && (
                <Animated.View style={[styles.messageContainer, styles.successMessage, { opacity: fadeAnim }]}>
                    <Ionicons name="checkmark-circle" size={20} color="#10b981" />
                    <Text style={styles.successMessageText}>{successMessage}</Text>
                </Animated.View>
            )}

            {showErrorMessage && (
                <Animated.View style={[styles.messageContainer, styles.errorMessage, { opacity: fadeAnim }]}>
                    <Ionicons name="alert-circle" size={20} color="#ef4444" />
                    <Text style={styles.errorMessageText}>{errorMessageText}</Text>
                </Animated.View>
            )}

            {/* Modal de Criação de Pedido */}
            <Modal
                transparent
                visible={orderModalVisible}
                animationType="fade"
                onRequestClose={() => setOrderModalVisible(false)}
            >
                <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
                    <View style={styles.modalOverlay}>
                        <TouchableWithoutFeedback>
                            <View style={styles.modalContent}>
                                <Ionicons name="basket" size={48} color="#3b82f6" />
                                <Text style={styles.modalTitle}>Criar Pedido</Text>
                                <Text style={styles.modalText}>
                                    Deseja criar um pedido para "{part.name}"?
                                </Text>

                                <View style={styles.formGroup}>
                                    <Text style={styles.label}>Notas (opcional)</Text>
                                    <TextInput
                                        style={styles.textArea}
                                        placeholder="Adicione observações sobre o pedido..."
                                        placeholderTextColor="#9ca3af"
                                        value={orderNotes}
                                        onChangeText={setOrderNotes}
                                        multiline
                                        numberOfLines={4}
                                        textAlignVertical="top"
                                        blurOnSubmit={true}
                                        returnKeyType="done"
                                    />
                                </View>

                                <View style={styles.modalButtons}>
                                    <TouchableOpacity
                                        style={styles.modalButtonCancel}
                                        onPress={() => {
                                            Keyboard.dismiss();
                                            setOrderModalVisible(false);
                                        }}
                                        disabled={orderLoading}
                                    >
                                        <Text style={styles.modalButtonCancelText}>Cancelar</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity
                                        style={styles.modalButtonConfirm}
                                        onPress={handleCreateOrder}
                                        disabled={orderLoading}
                                    >
                                        {orderLoading ? (
                                            <ActivityIndicator size="small" color="#fff" />
                                        ) : (
                                            <Text style={styles.modalButtonConfirmText}>Criar Pedido</Text>
                                        )}
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </TouchableWithoutFeedback>
                    </View>
                </TouchableWithoutFeedback>
            </Modal>

            {/* Modal de Confirmação de Eliminação */}
            {canDelete && (
                <Modal
                    transparent
                    visible={deleteModalVisible}
                    animationType="fade"
                    onRequestClose={() => setDeleteModalVisible(false)}
                >
                    <View style={styles.modalOverlay}>
                        <View style={styles.modalContent}>
                            <Ionicons name="warning" size={48} color="#ef4444" />
                            <Text style={styles.modalTitle}>Eliminar Peça?</Text>
                            <Text style={styles.modalText}>
                                Tem certeza que deseja eliminar a peça "{part.name}"?
                            </Text>
                            <Text style={styles.modalWarning}>
                                Esta ação não pode ser desfeita!
                            </Text>

                            <View style={styles.modalButtons}>
                                <TouchableOpacity
                                    style={styles.modalButtonCancel}
                                    onPress={() => setDeleteModalVisible(false)}
                                    disabled={deleteLoading}
                                >
                                    <Text style={styles.modalButtonCancelText}>Cancelar</Text>
                                </TouchableOpacity>
                                <TouchableOpacity
                                    style={styles.modalButtonDelete}
                                    onPress={handleDelete}
                                    disabled={deleteLoading}
                                >
                                    {deleteLoading ? (
                                        <ActivityIndicator size="small" color="#fff" />
                                    ) : (
                                        <Text style={styles.modalButtonDeleteText}>Eliminar</Text>
                                    )}
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </Modal>
            )}

            {/* Header com Botão Voltar */}
            <View style={styles.headerContainer}>
                <View style={styles.headerBar}>
                    <TouchableOpacity onPress={handleBack} style={styles.backButton}>
                        <Ionicons name="arrow-back" size={24} color="#111827" />
                        <Text style={styles.backText}>Voltar</Text>
                    </TouchableOpacity>
                </View>

                {/* Botões de Ação em Linha */}
                <View style={styles.actionsContainer}>
                    {/* Favoritos */}
                    {canFavorite && (
                        <TouchableOpacity 
                            onPress={handleToggleFavorite} 
                            style={[
                                styles.actionButton,
                                isFavorite && styles.favoriteButtonActive
                            ]}
                            disabled={favoriteLoading}
                        >
                            {favoriteLoading ? (
                                <ActivityIndicator size="small" color="#fff" />
                            ) : (
                                <Ionicons 
                                    name={isFavorite ? "heart" : "heart-outline"} 
                                    size={20} 
                                    color="#fff" 
                                />
                            )}
                        </TouchableOpacity>
                    )}

                    {/* Fazer Pedido */}
                    {canOrder && (
                        <TouchableOpacity 
                            onPress={handleOpenOrderModal} 
                            style={[styles.actionButton, styles.orderButtonStyle]}
                        >
                            <Ionicons name="basket" size={20} color="#fff" />
                        </TouchableOpacity>
                    )}

                    {/* WhatsApp */}
                    {canWhatsapp && (
                        <TouchableOpacity 
                            onPress={handleWhatsappReservation} 
                            style={[styles.actionButton, styles.whatsappButtonStyle]}
                            disabled={whatsappLoading}
                        >
                            {whatsappLoading ? (
                                <ActivityIndicator size="small" color="#fff" />
                            ) : (
                                <Ionicons name="logo-whatsapp" size={20} color="#fff" />
                            )}
                        </TouchableOpacity>
                    )}

                    {/* Movimento */}
                    {canMovement && (
                        <TouchableOpacity 
                            onPress={handleMovement} 
                            style={[styles.actionButton, styles.movementButtonStyle]}
                        >
                            <Ionicons name="swap-horizontal" size={20} color="#fff" />
                        </TouchableOpacity>
                    )}

                    {/* Editar */}
                    {canEdit && (
                        <TouchableOpacity 
                            onPress={handleEdit} 
                            style={[styles.actionButton, styles.editButtonStyle]}
                        >
                            <Ionicons name="create-outline" size={20} color="#fff" />
                        </TouchableOpacity>
                    )}

                    {/* Eliminar */}
                    {canDelete && (
                        <TouchableOpacity 
                            onPress={() => setDeleteModalVisible(true)} 
                            style={[styles.actionButton, styles.deleteButtonStyle]}
                        >
                            <Ionicons name="trash-outline" size={20} color="#fff" />
                        </TouchableOpacity>
                    )}
                </View>
            </View>

            <ScrollView style={styles.content}>
                <View style={styles.card}>
                    {/* Galeria de Imagens */}
                    <View style={styles.imageSection}>
                        <View style={styles.mainImageContainer}>
                            {part.images && part.images.length > 0 ? (
                                <Image
                                    source={{ uri: part.images[selectedImageIndex].url }}
                                    style={styles.mainImage}
                                    contentFit="contain"
                                />
                            ) : (
                                <View style={styles.placeholderImage}>
                                    <Ionicons name="image-outline" size={80} color="#9ca3af" />
                                </View>
                            )}
                            
                            <View style={styles.conditionBadge}>
                                <Text style={styles.conditionText}>
                                    {getConditionName(part.condition)}
                                </Text>
                            </View>

                            {isFavorite && (
                                <View style={styles.favoriteBadge}>
                                    <Ionicons name="heart" size={16} color="#fff" />
                                </View>
                            )}
                        </View>

                        {part.images && part.images.length > 1 && (
                            <View style={styles.thumbnailContainer}>
                                {part.images.map((image, index) => (
                                    <TouchableOpacity
                                        key={image.id}
                                        onPress={() => setSelectedImageIndex(index)}
                                        style={[
                                            styles.thumbnail,
                                            selectedImageIndex === index && styles.thumbnailActive
                                        ]}
                                    >
                                        <Image
                                            source={{ uri: image.url }}
                                            style={styles.thumbnailImage}
                                            contentFit="cover"
                                        />
                                    </TouchableOpacity>
                                ))}
                            </View>
                        )}
                    </View>

                    {/* Informações Principais */}
                    <View style={styles.infoSection}>
                        <Text style={styles.partName}>{part.name}</Text>
                        <Text style={styles.partPrice}>{formatPrice(part.price)}</Text>
                        
                        <View style={styles.divider} />

                        <View style={styles.infoRow}>
                            <Text style={styles.infoLabel}>Referência Interna:</Text>
                            <Text style={styles.infoValue}>{part.refInternal}</Text>
                        </View>

                        {part.refOEM && (
                            <View style={styles.infoRow}>
                                <Text style={styles.infoLabel}>Referência OEM:</Text>
                                <Text style={styles.infoValue}>{part.refOEM}</Text>
                            </View>
                        )}

                        <View style={styles.infoRow}>
                            <Text style={styles.infoLabel}>Categoria:</Text>
                            <Text style={styles.infoValue}>{part.category.name}</Text>
                        </View>

                        <View style={styles.infoRow}>
                            <Text style={styles.infoLabel}>Localização:</Text>
                            <Text style={styles.infoValue}>{part.location.fullCode}</Text>
                        </View>

                        {part.description && (
                            <>
                                <View style={styles.divider} />
                                <Text style={styles.sectionTitle}>Descrição</Text>
                                <Text style={styles.description}>{part.description}</Text>
                            </>
                        )}

                        {part.specifications && part.specifications.length > 0 && (
                            <>
                                <View style={styles.divider} />
                                <Text style={styles.sectionTitle}>Especificações</Text>
                                {part.specifications.map((spec) => (
                                    <View key={spec.id} style={styles.specRow}>
                                        <Text style={styles.specLabel}>{spec.spec.name}:</Text>
                                        <Text style={styles.specValue}>{spec.value}</Text>
                                    </View>
                                ))}
                            </>
                        )}

                        {part.subReferences && part.subReferences.length > 0 && (
                            <>
                                <View style={styles.divider} />
                                <Text style={styles.sectionTitle}>Sub-Referências</Text>
                                <View style={styles.subRefsContainer}>
                                    {part.subReferences.map((subRef) => (
                                        <View key={subRef.id} style={styles.subRefChip}>
                                            <Text style={styles.subRefText}>{subRef.value}</Text>
                                        </View>
                                    ))}
                                </View>
                            </>
                        )}
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f9fafb',
    },
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f9fafb',
        padding: 20,
    },
    loadingText: {
        marginTop: 12,
        fontSize: 16,
        color: '#6b7280',
    },
    errorText: {
        marginTop: 12,
        fontSize: 16,
        color: '#ef4444',
        textAlign: 'center',
    },
    retryButton: {
        marginTop: 16,
        paddingHorizontal: 24,
        paddingVertical: 12,
        backgroundColor: '#3b82f6',
        borderRadius: 8,
    },
    retryButtonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '600',
    },
    messageContainer: {
        position: 'absolute',
        top: 80,
        left: 16,
        right: 16,
        flexDirection: 'row',
        alignItems: 'center',
        padding: 16,
        borderRadius: 12,
        zIndex: 1000,
        elevation: 5,
        shadowColor: '#000',
        shadowOpacity: 0.2,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
    },
    successMessage: {
        backgroundColor: '#d1fae5',
        borderWidth: 1,
        borderColor: '#10b981',
    },
    errorMessage: {
        backgroundColor: '#fee2e2',
        borderWidth: 1,
        borderColor: '#ef4444',
    },
    successMessageText: {
        marginLeft: 12,
        fontSize: 14,
        color: '#065f46',
        fontWeight: '600',
        flex: 1,
    },
    errorMessageText: {
        marginLeft: 12,
        fontSize: 14,
        color: '#991b1b',
        fontWeight: '600',
        flex: 1,
    },
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    modalContent: {
        backgroundColor: '#fff',
        borderRadius: 16,
        padding: 24,
        width: '100%',
        maxWidth: 400,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOpacity: 0.25,
        shadowRadius: 8,
        shadowOffset: { width: 0, height: 4 },
        elevation: 10,
    },
    modalTitle: {
        fontSize: 20,
        fontWeight: '700',
        color: '#111827',
        marginTop: 16,
        marginBottom: 8,
    },
    modalText: {
        fontSize: 14,
        color: '#6b7280',
        textAlign: 'center',
        marginBottom: 16,
    },
    modalWarning: {
        fontSize: 12,
        color: '#ef4444',
        textAlign: 'center',
        fontWeight: '600',
        marginBottom: 24,
    },
    formGroup: {
        width: '100%',
        marginBottom: 16,
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        color: '#374151',
        marginBottom: 8,
    },
    textArea: {
        backgroundColor: '#f9fafb',
        borderWidth: 1,
        borderColor: '#d1d5db',
        borderRadius: 8,
        padding: 12,
        fontSize: 14,
        color: '#111827',
        minHeight: 100,
        textAlignVertical: 'top',
    },
    modalButtons: {
        flexDirection: 'row',
        gap: 12,
        width: '100%',
    },
    modalButtonCancel: {
        flex: 1,
        paddingVertical: 12,
        backgroundColor: '#f3f4f6',
        borderRadius: 8,
        alignItems: 'center',
    },
    modalButtonCancelText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#6b7280',
    },
    modalButtonConfirm: {
        flex: 1,
        paddingVertical: 12,
        backgroundColor: '#3b82f6',
        borderRadius: 8,
        alignItems: 'center',
    },
    modalButtonConfirmText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#fff',
    },
    modalButtonDelete: {
        flex: 1,
        paddingVertical: 12,
        backgroundColor: '#ef4444',
        borderRadius: 8,
        alignItems: 'center',
    },
    modalButtonDeleteText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#fff',
    },
    headerContainer: {
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderBottomColor: '#e5e7eb',
    },
    headerBar: {
        padding: 16,
    },
    backButton: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
    },
    backText: {
        fontSize: 16,
        color: '#111827',
        fontWeight: '500',
    },
    actionsContainer: {
        flexDirection: 'row',
        paddingHorizontal: 16,
        paddingBottom: 12,
        gap: 8,
        flexWrap: 'wrap',
    },
    actionButton: {
        width: 44,
        height: 44,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#9ca3af',
        borderRadius: 8,
    },
    favoriteButtonActive: {
        backgroundColor: '#eab308',
    },
    orderButtonStyle: {
        backgroundColor: '#10b981',
    },
    whatsappButtonStyle: {
        backgroundColor: '#25D366',
    },
    movementButtonStyle: {
        backgroundColor: '#6b7280',
    },
    editButtonStyle: {
        backgroundColor: '#3b82f6',
    },
    deleteButtonStyle: {
        backgroundColor: '#ef4444',
    },
    content: {
        flex: 1,
        padding: 16,
    },
    card: {
        backgroundColor: '#fff',
        borderRadius: 12,
        overflow: 'hidden',
        elevation: 2,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
    },
    imageSection: {
        padding: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#e5e7eb',
    },
    mainImageContainer: {
        width: '100%',
        height: 400,
        backgroundColor: '#f3f4f6',
        borderRadius: 8,
        overflow: 'hidden',
        position: 'relative',
    },
    mainImage: {
        width: '100%',
        height: '100%',
    },
    placeholderImage: {
        width: '100%',
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f3f4f6',
    },
    conditionBadge: {
        position: 'absolute',
        top: 12,
        right: 12,
        backgroundColor: 'rgba(59, 130, 246, 0.9)',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 6,
    },
    conditionText: {
        fontSize: 12,
        color: '#fff',
        fontWeight: '600',
    },
    favoriteBadge: {
        position: 'absolute',
        top: 12,
        left: 12,
        backgroundColor: 'rgba(234, 179, 8, 0.9)',
        paddingHorizontal: 10,
        paddingVertical: 6,
        borderRadius: 6,
        flexDirection: 'row',
        alignItems: 'center',
    },
    thumbnailContainer: {
        flexDirection: 'row',
        gap: 8,
        marginTop: 12,
    },
    thumbnail: {
        width: 80,
        height: 80,
        borderRadius: 8,
        overflow: 'hidden',
        borderWidth: 2,
        borderColor: 'transparent',
    },
    thumbnailActive: {
        borderColor: '#3b82f6',
    },
    thumbnailImage: {
        width: '100%',
        height: '100%',
    },
    infoSection: {
        padding: 20,
    },
    partName: {
        fontSize: 24,
        fontWeight: '700',
        color: '#111827',
        marginBottom: 8,
    },
    partPrice: {
        fontSize: 28,
        fontWeight: '700',
        color: '#3b82f6',
        marginBottom: 16,
    },
    divider: {
        height: 1,
        backgroundColor: '#e5e7eb',
        marginVertical: 16,
    },
    infoRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 8,
    },
    infoLabel: {
        fontSize: 14,
        color: '#6b7280',
        fontWeight: '500',
    },
    infoValue: {
        fontSize: 14,
        color: '#111827',
        fontWeight: '600',
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#111827',
        marginBottom: 12,
    },
    description: {
        fontSize: 14,
        color: '#6b7280',
        lineHeight: 20,
    },
    specRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 6,
    },
    specLabel: {
        fontSize: 14,
        color: '#6b7280',
    },
    specValue: {
        fontSize: 14,
        color: '#111827',
        fontWeight: '500',
    },
    subRefsContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 8,
    },
    subRefChip: {
        backgroundColor: '#eff6ff',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 16,
        borderWidth: 1,
        borderColor: '#3b82f6',
    },
    subRefText: {
        fontSize: 12,
        color: '#3b82f6',
        fontWeight: '500',
    },
});

export default PartDetails;