import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    TouchableOpacity,
    ActivityIndicator,
    Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, useLocalSearchParams } from 'expo-router';
import Header from '../../(shared)/Header';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getWarehouses, Warehouse } from '../../(services)/warehouseService';
import { ApiError } from '../../(services)/authService';

const SelectWarehouse = () => {
    const router = useRouter();
    const params = useLocalSearchParams();
    const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
    const [loading, setLoading] = useState(true);

    // ✅ Capturar se veio da página de edição
    const fromEdit = params.fromEdit === 'true';
    const partId = params.partId as string;

    useEffect(() => {
        loadWarehouses();
    }, []);

    const loadWarehouses = async () => {
        try {
            setLoading(true);
            const data = await getWarehouses();
            setWarehouses(data);
        } catch (error) {
            const apiError = error as ApiError;
            Alert.alert('Erro', apiError.message);
        } finally {
            setLoading(false);
        }
    };

    const handleLogoutPress = async () => {
        try {
            await AsyncStorage.removeItem('userToken');
            router.replace('/login');
        } catch (error) {
            console.error('Erro ao fazer logout:', error);
            Alert.alert('Erro', 'Não foi possível fazer logout');
        }
    };

    const handleBack = () => {
        if (fromEdit && partId) {
            router.push(`/Parts/editPart?id=${partId}`);
        } else {
            router.push('/Parts/createPart');
        }
    };

    const handleSelectWarehouse = (warehouse: Warehouse) => {
        // ✅ Passar informação de edição para próxima tela
        router.push({
            pathname: '../Parts/SelectLocation',
            params: {
                warehouseId: warehouse.id,
                warehouseName: warehouse.name,
                fromEdit: fromEdit ? 'true' : 'false',
                partId: partId || '',
            },
        });
    };

    const renderWarehouseCard = ({ item }: { item: Warehouse }) => (
        <TouchableOpacity
            style={styles.card}
            onPress={() => handleSelectWarehouse(item)}
            activeOpacity={0.7}
        >
            <View style={styles.cardHeader}>
                <View style={styles.iconContainer}>
                    <Ionicons 
                        name={item.code === 'CAIXAS' ? 'cube' : 'business'} 
                        size={28} 
                        color="#3b82f6" 
                    />
                </View>
                <View style={styles.cardInfo}>
                    <Text style={styles.cardTitle}>{item.name}</Text>
                    <Text style={styles.cardCode}>Código: {item.code}</Text>
                </View>
            </View>
            
            <View style={styles.cardFooter}>
                <View style={styles.locationCount}>
                    <Ionicons name="location" size={16} color="#6b7280" />
                    <Text style={styles.locationCountText}>
                        {item.locationCount} {item.locationCount === 1 ? 'localização' : 'localizações'}
                    </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#9ca3af" />
            </View>
        </TouchableOpacity>
    );

    if (loading) {
        return (
            <SafeAreaView style={styles.container}>
                <Header onProfilePress={() => router.push('/profile')} onLogoutPress={handleLogoutPress} />
                <View style={styles.centerContainer}>
                    <ActivityIndicator size="large" color="#3b82f6" />
                    <Text style={styles.loadingText}>Carregando warehouses...</Text>
                </View>
            </SafeAreaView>
        );
    }

    return (
        <SafeAreaView style={styles.container}>
            <Header onProfilePress={() => router.push('/profile')} onLogoutPress={handleLogoutPress} />
            
            <View style={styles.headerBar}>
                <TouchableOpacity onPress={handleBack} style={styles.backButton}>
                    <Ionicons name="arrow-back" size={24} color="#111827" />
                    <Text style={styles.backText}>Voltar</Text>
                </TouchableOpacity>
                
                <Text style={styles.headerTitle}>Selecionar Warehouse</Text>
                
                <View style={styles.placeholder} />
            </View>

            {warehouses.length === 0 ? (
                <View style={styles.emptyContainer}>
                    <Ionicons name="business-outline" size={64} color="#d1d5db" />
                    <Text style={styles.emptyTitle}>Nenhum warehouse encontrado</Text>
                    <Text style={styles.emptyText}>
                        Não existem warehouses cadastrados no sistema.
                    </Text>
                </View>
            ) : (
                <FlatList
                    data={warehouses}
                    renderItem={renderWarehouseCard}
                    keyExtractor={(item) => item.id.toString()}
                    contentContainerStyle={styles.listContainer}
                    showsVerticalScrollIndicator={false}
                />
            )}
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f9fafb',
    },
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    loadingText: {
        marginTop: 12,
        fontSize: 16,
        color: '#6b7280',
    },
    headerBar: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 16,
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderBottomColor: '#e5e7eb',
    },
    backButton: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        flex: 1,
    },
    backText: {
        fontSize: 16,
        color: '#111827',
        fontWeight: '500',
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#111827',
        flex: 2,
        textAlign: 'center',
    },
    placeholder: {
        flex: 1,
    },
    listContainer: {
        padding: 16,
    },
    card: {
        backgroundColor: '#fff',
        borderRadius: 12,
        padding: 16,
        marginBottom: 12,
        elevation: 2,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
    },
    cardHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
    },
    iconContainer: {
        width: 56,
        height: 56,
        borderRadius: 28,
        backgroundColor: '#eff6ff',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 12,
    },
    cardInfo: {
        flex: 1,
    },
    cardTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#111827',
        marginBottom: 4,
    },
    cardCode: {
        fontSize: 14,
        color: '#6b7280',
    },
    cardFooter: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingTop: 12,
        borderTopWidth: 1,
        borderTopColor: '#f3f4f6',
    },
    locationCount: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
    },
    locationCountText: {
        fontSize: 14,
        color: '#6b7280',
    },
    emptyContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 40,
    },
    emptyTitle: {
        fontSize: 20,
        fontWeight: '600',
        color: '#111827',
        marginTop: 16,
        marginBottom: 8,
    },
    emptyText: {
        fontSize: 14,
        color: '#6b7280',
        textAlign: 'center',
        lineHeight: 20,
    },
});

export default SelectWarehouse;