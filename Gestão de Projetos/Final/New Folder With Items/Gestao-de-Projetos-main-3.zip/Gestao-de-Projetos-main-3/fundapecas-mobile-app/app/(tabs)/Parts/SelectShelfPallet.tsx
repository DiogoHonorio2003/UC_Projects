import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Alert,
    Image,
    ScrollView,
    ActivityIndicator,
    Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Picker } from '@react-native-picker/picker';
import Header from '../../(shared)/Header';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SelectShelfPallet = () => {
    const router = useRouter();
    const params = useLocalSearchParams();
    const locationCode = params.selectedLocationCode as string;
    const warehouseName = params.warehouseName as string;
    const warehouseId = Number(params.warehouseId);
    
    // ✅ Capturar informação de edição
    const fromEdit = params.fromEdit === 'true';
    const partId = params.partId as string;
    
    const [selectedShelfPallet, setSelectedShelfPallet] = useState('');
    const [loading, setLoading] = useState(false);

    const isUpperWarehouse = warehouseId === 1;
    const isBoxWarehouse = warehouseId === 4;

    const boxShelfPallets = [
        'A', 'B', 'C',
        'D', 'E', 'F',
        'G', 'H', 'I',
        'J', 'K', 'L',
        'M', 'N', 'O',
    ];

    const upperShelfPallets = [
        'A', 'B', 'C',
        'D', 'E', 'F',
        'G', 'H', 'I',
        'J', 'K', 'L',
        'M', 'N', 'O',
        'P', 'Q', 'R',
    ];

    const lowerShelfPallets = [
        'A', 'B', 'C',
        'D', 'E', 'F',
        'G', 'H', 'I',
        'J', 'K', 'L',
        'M', 'N', 'O',
    ];

    const allShelfPallets = isBoxWarehouse ? boxShelfPallets :
                            isUpperWarehouse ? upperShelfPallets : 
                            lowerShelfPallets;

    const handleLogoutPress = async () => {
        try {
            await AsyncStorage.removeItem('userToken');
            router.replace('/login');
        } catch (error) {
            console.error('Erro ao fazer logout:', error);
            Alert.alert('Erro', 'Não foi possível fazer logout');
        }
    };

    const handleBack = () => {
        router.back();
    };

    const getLocationIdByFullCode = async (fullCode: string): Promise<number | null> => {
        try {
            const API_URL = process.env.EXPO_PUBLIC_API_URL;
            const token = await AsyncStorage.getItem('userToken');

            const response = await fetch(`${API_URL}/warehouses/${warehouseId}/locations`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error('Erro ao buscar localizações');
            }

            const locations = await response.json();
            const location = locations.find((loc: any) => loc.fullCode === fullCode);
            
            if (location) {
                console.log('✅ Localização encontrada:', location);
                return location.id;
            } else {
                console.error('❌ Localização não encontrada para fullCode:', fullCode);
                return null;
            }
        } catch (error) {
            console.error('❌ Erro ao buscar ID da localização:', error);
            return null;
        }
    };

    const handleConfirmSelection = async () => {
        if (!selectedShelfPallet) {
            Alert.alert('Atenção', 'Por favor, selecione uma prateleira/palete');
            return;
        }

        try {
            setLoading(true);

            let fullCode: string;
            
            if (isBoxWarehouse) {
                fullCode = `CAIXAS-${locationCode}-${selectedShelfPallet}`;
            } else if (isUpperWarehouse) {
                const nivel = getNivelFromShelfPallet(selectedShelfPallet, true);
                fullCode = `ACIMA-${locationCode}-${nivel}-${selectedShelfPallet}`;
            } else {
                const nivel = getNivelFromShelfPallet(selectedShelfPallet, false);
                fullCode = `ABAIXO-${locationCode}-${nivel}-${selectedShelfPallet}`;
            }

            console.log('🔍 FullCode gerado:', fullCode);

            const locationId = await getLocationIdByFullCode(fullCode);

            if (!locationId) {
                Alert.alert('Erro', 'Não foi possível encontrar a localização no sistema. Por favor, tente novamente.');
                setLoading(false);
                return;
            }

            // ✅ Redirecionar baseado em fromEdit
            if (fromEdit && partId) {
                router.replace({
                    pathname: `/Parts/editPart`,
                    params: {
                        id: partId,
                        selectedLocationId: locationId.toString(),
                        selectedLocationCode: fullCode,
                        selectedLocationCapacity: '0/10',
                    },
                });
            } else {
                router.replace({
                    pathname: '/Parts/createPart',
                    params: {
                        selectedLocationId: locationId.toString(),
                        selectedLocationCode: fullCode,
                        selectedLocationCapacity: '0/10',
                    },
                });
            }
        } catch (error) {
            console.error('❌ Erro ao confirmar seleção:', error);
            Alert.alert('Erro', 'Ocorreu um erro ao processar a seleção');
        } finally {
            setLoading(false);
        }
    };

    const getNivelFromShelfPallet = (shelfPallet: string, isUpper: boolean): number => {
        const upperMapping: { [key: string]: number } = {
            'A': 0, 'B': 0, 'C': 0,
            'D': 1, 'E': 1, 'F': 1,
            'G': 2, 'H': 2, 'I': 2,
            'J': 3, 'K': 3, 'L': 3,
            'M': 4, 'N': 4, 'O': 4,
            'P': 5, 'Q': 5, 'R': 5,
        };

        const lowerMapping: { [key: string]: number } = {
            'A': 0, 'B': 0, 'C': 0,
            'D': 1, 'E': 1, 'F': 1,
            'G': 2, 'H': 2, 'I': 2,
            'J': 3, 'K': 3, 'L': 3,
            'M': 4, 'N': 4, 'O': 4,
        };

        return isUpper ? upperMapping[shelfPallet] : lowerMapping[shelfPallet];
    };

    const renderBoxPicker = () => (
        <Picker
            selectedValue={selectedShelfPallet}
            onValueChange={(itemValue) => setSelectedShelfPallet(itemValue)}
            style={styles.picker}
            mode="dropdown"
            itemStyle={Platform.OS === 'ios' ? styles.pickerItem : undefined}
        >
            <Picker.Item label="Selecione uma prateleira/palete..." value="" />
            
            <Picker.Item label="─── NÍVEL 4 (Topo) ───" value="" enabled={false} />
            {['M', 'N', 'O'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── NÍVEL 3 ───" value="" enabled={false} />
            {['J', 'K', 'L'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── NÍVEL 2 ───" value="" enabled={false} />
            {['G', 'H', 'I'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── NÍVEL 1 ───" value="" enabled={false} />
            {['D', 'E', 'F'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── NÍVEL 0 (Base) ───" value="" enabled={false} />
            {['A', 'B', 'C'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
        </Picker>
    );

    const renderUpperWarehousePicker = () => (
        <Picker
            selectedValue={selectedShelfPallet}
            onValueChange={(itemValue) => setSelectedShelfPallet(itemValue)}
            style={styles.picker}
            mode="dropdown"
            itemStyle={Platform.OS === 'ios' ? styles.pickerItem : undefined}
        >
            <Picker.Item label="Selecione uma prateleira/palete..." value="" />
            
            <Picker.Item label="─── NÍVEL 5 (Topo) ───" value="" enabled={false} />
            {['P', 'Q', 'R'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── NÍVEL 4 ───" value="" enabled={false} />
            {['M', 'N', 'O'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── NÍVEL 3 ───" value="" enabled={false} />
            {['J', 'K', 'L'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── NÍVEL 2 ───" value="" enabled={false} />
            {['G', 'H', 'I'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── NÍVEL 1 ───" value="" enabled={false} />
            {['D', 'E', 'F'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── NÍVEL 0 (Base) ───" value="" enabled={false} />
            {['A', 'B', 'C'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
        </Picker>
    );

    const renderLowerWarehousePicker = () => (
        <Picker
            selectedValue={selectedShelfPallet}
            onValueChange={(itemValue) => setSelectedShelfPallet(itemValue)}
            style={styles.picker}
            mode="dropdown"
            itemStyle={Platform.OS === 'ios' ? styles.pickerItem : undefined}
        >
            <Picker.Item label="Selecione uma prateleira/palete..." value="" />
            
            <Picker.Item label="─── NÍVEL 4 (Topo) ───" value="" enabled={false} />
            {['M', 'N', 'O'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── NÍVEL 3 ───" value="" enabled={false} />
            {['J', 'K', 'L'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── NÍVEL 2 ───" value="" enabled={false} />
            {['G', 'H', 'I'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── NÍVEL 1 ───" value="" enabled={false} />
            {['D', 'E', 'F'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── NÍVEL 0 (Base) ───" value="" enabled={false} />
            {['A', 'B', 'C'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
        </Picker>
    );

    return (
        <SafeAreaView style={styles.container}>
            <Header onProfilePress={() => router.push('/profile')} onLogoutPress={handleLogoutPress} />
            
            <View style={styles.headerBar}>
                <TouchableOpacity onPress={handleBack} style={styles.backButton}>
                    <Ionicons name="arrow-back" size={24} color="#111827" />
                    <Text style={styles.backText}>Voltar</Text>
                </TouchableOpacity>
                
                <View style={styles.headerTitleContainer}>
                    <Text style={styles.headerTitle}>Prateleira/Palete</Text>
                    <Text style={styles.headerSubtitle}>{warehouseName}</Text>
                </View>
                
                <View style={styles.placeholder} />
            </View>

            <ScrollView style={styles.content} contentContainerStyle={styles.contentContainer}>
                <View style={styles.imageContainer}>
                    <Image
                        source={
                            isBoxWarehouse
                                ? require('../../../assets/images/lowerShelfsPallets.png')
                                : isUpperWarehouse
                                    ? require('../../../assets/images/shelfsPallets.png')
                                    : require('../../../assets/images/lowerShelfsPallets.png')
                        }
                        style={styles.rackImage}
                        resizeMode="contain"
                    />
                </View>

                <View style={styles.infoCard}>
                    <View style={styles.infoRow}>
                        <Ionicons name="location" size={20} color="#3b82f6" />
                        <Text style={styles.infoText}>
                            {isBoxWarehouse ? 'Caixa:' : 'Localização:'} {' '}
                            <Text style={styles.infoBold}>
                                {isBoxWarehouse ? `Caixa ${locationCode}` : locationCode}
                            </Text>
                        </Text>
                    </View>
                    <View style={styles.infoRow}>
                        <Ionicons name="business" size={20} color="#3b82f6" />
                        <Text style={styles.infoText}>
                            Warehouse: <Text style={styles.infoBold}>{warehouseName}</Text>
                        </Text>
                    </View>
                    <View style={styles.infoRow}>
                        <Ionicons name="layers" size={20} color="#3b82f6" />
                        <Text style={styles.infoText}>
                            Estrutura: <Text style={styles.infoBold}>
                                {isBoxWarehouse || !isUpperWarehouse ? '5 Níveis (0-4)' : '6 Níveis (0-5)'}
                            </Text>
                        </Text>
                    </View>
                </View>

                <View style={styles.selectorContainer}>
                    <Text style={styles.selectorLabel}>Selecione a Prateleira/Palete:</Text>
                    
                    <View style={styles.pickerContainer}>
                        {isBoxWarehouse ? renderBoxPicker() :
                         isUpperWarehouse ? renderUpperWarehousePicker() : 
                         renderLowerWarehousePicker()}
                    </View>

                    {selectedShelfPallet && (
                        <View style={styles.selectedInfo}>
                            <Ionicons name="checkmark-circle" size={20} color="#10b981" />
                            <Text style={styles.selectedText}>
                                Selecionado: <Text style={styles.selectedCode}>
                                    {selectedShelfPallet} (Nível {getNivelFromShelfPallet(selectedShelfPallet, isUpperWarehouse)})
                                </Text>
                            </Text>
                        </View>
                    )}
                </View>

                <TouchableOpacity
                    style={[styles.confirmButton, (!selectedShelfPallet || loading) && styles.confirmButtonDisabled]}
                    onPress={handleConfirmSelection}
                    disabled={!selectedShelfPallet || loading}
                >
                    {loading ? (
                        <ActivityIndicator size="small" color="#fff" />
                    ) : (
                        <>
                            <Text style={styles.confirmButtonText}>Confirmar Localização Completa</Text>
                            <Ionicons name="arrow-forward" size={20} color="#fff" />
                        </>
                    )}
                </TouchableOpacity>
            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f9fafb',
    },
    headerBar: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 16,
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderBottomColor: '#e5e7eb',
    },
    backButton: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        flex: 1,
    },
    backText: {
        fontSize: 16,
        color: '#111827',
        fontWeight: '500',
    },
    headerTitleContainer: {
        flex: 2,
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#111827',
    },
    headerSubtitle: {
        fontSize: 12,
        color: '#6b7280',
        marginTop: 2,
    },
    placeholder: {
        flex: 1,
    },
    content: {
        flex: 1,
    },
    contentContainer: {
        padding: 16,
    },
    imageContainer: {
        backgroundColor: '#fff',
        borderRadius: 12,
        padding: 16,
        marginBottom: 16,
        elevation: 2,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
    },
    rackImage: {
        width: '100%',
        height: 400,
    },
    infoCard: {
        backgroundColor: '#fff',
        borderRadius: 12,
        padding: 16,
        marginBottom: 16,
        gap: 12,
        elevation: 2,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
    },
    infoRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
    },
    infoText: {
        fontSize: 14,
        color: '#6b7280',
    },
    infoBold: {
        fontWeight: '600',
        color: '#111827',
        fontSize: 15,
    },
    selectorContainer: {
        backgroundColor: '#fff',
        borderRadius: 12,
        padding: 16,
        marginBottom: 16,
        elevation: 2,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
    },
    selectorLabel: {
        fontSize: 14,
        fontWeight: '600',
        color: '#111827',
        marginBottom: 8,
    },
    pickerContainer: {
        borderWidth: 1,
        borderColor: '#d1d5db',
        borderRadius: 8,
        backgroundColor: '#fff',
        ...Platform.select({
            ios: {
                minHeight: 150,
            },
            android: {
                height: 50,
            },
        }),
    },
    picker: {
        ...Platform.select({
            ios: {
                height: 150,
                marginVertical: -10,
            },
            android: {
                height: 50,
                color: '#111827',
            },
            default: {
                height: 45,
            },
        }),
    },
    pickerItem: {
        height: 150,
        fontSize: 16,
        color: '#111827',
    },
    selectedInfo: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        marginTop: 12,
        padding: 10,
        backgroundColor: '#d1fae5',
        borderRadius: 8,
    },
    selectedText: {
        fontSize: 13,
        color: '#065f46',
        flex: 1,
    },
    selectedCode: {
        fontWeight: '700',
        fontSize: 14,
    },
    confirmButton: {
        backgroundColor: '#3b82f6',
        borderRadius: 12,
        padding: 16,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        elevation: 2,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
    },
    confirmButtonDisabled: {
        backgroundColor: '#9ca3af',
        opacity: 0.5,
    },
    confirmButtonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '600',
    },
});

export default SelectShelfPallet;