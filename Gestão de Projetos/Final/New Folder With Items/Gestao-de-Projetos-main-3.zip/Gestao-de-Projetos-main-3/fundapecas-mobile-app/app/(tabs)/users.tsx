import { useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  ActivityIndicator,
  TextInput,
  Alert,
  ScrollView,
  Pressable,
  Modal,
  TouchableOpacity,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { ApiError, getMe } from "../(services)/authService";
import {
  activateUser,
  adminResetPassword,
  deactivateUser,
  getUsers,
  registerUser,
  updateUser,
  UserRole,
  UserSummary,
} from "../(services)/usersService";

const roleOptions: UserRole[] = ["CLIENT", "SALES", "WAREHOUSE", "ADMIN"];

function validateStrongPassword(pw: string): string | null {
  if (!pw) return "Password é obrigatória.";
  if (pw.length < 6 || pw.length > 100) return "Password inválida (6-100 caracteres).";
  if (!/[a-z]/.test(pw) || !/[A-Z]/.test(pw) || !/[0-9]/.test(pw)) {
    return "Password fraca: precisa de minúscula, maiúscula e número.";
  }
  return null;
}

function validateUsername(u: string): string | null {
  const t = u.trim();
  if (!t || t.length < 3 || t.length > 30) return "Username inválido (3-30 caracteres).";
  if (!/^[a-zA-Z0-9_]+$/.test(t)) return "Username inválido (apenas letras, números e underscore).";
  return null;
}

function validateEmail(email: string): string | null {
  const t = email.trim();
  if (!t) return null; // opcional
  if (t.length > 255) return "Email inválido (máximo 255 caracteres).";
  // validação simples
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t)) return "Email inválido.";
  return null;
}

function validateFullName(n: string): string | null {
  const t = n.trim();
  if (!t || t.length < 2 || t.length > 100) return "Full name inválido (2-100 caracteres).";
  return null;
}

export default function UsersAdminScreen() {
  const [loading, setLoading] = useState(true);
  const [adminOk, setAdminOk] = useState<boolean | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [meId, setMeId] = useState<number | null>(null);

  // USERS LIST
  const [usersLoading, setUsersLoading] = useState(false);
  const [users, setUsers] = useState<UserSummary[]>([]);
  const [search, setSearch] = useState("");

  // MANAGE USER MODAL (edit + activate/deactivate + reset)
  const [manageOpen, setManageOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<UserSummary | null>(null);

  const [editUsername, setEditUsername] = useState("");
  const [editEmail, setEditEmail] = useState("");
  const [editFullName, setEditFullName] = useState("");
  const [editRole, setEditRole] = useState<UserRole>("CLIENT");

  const [resetNewPassword, setResetNewPassword] = useState("");
  const [resetPressed, setResetPressed] = useState(false);

  // CREATE USER (modal via FAB)
  const [createOpen, setCreateOpen] = useState(false);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<UserRole>("CLIENT");

  const handleBack = () => {
    if (router.canGoBack()) {
      router.back();
    } else {
      router.replace("/(tabs)/home");
    }
  };

  const showError = (msg: string) => setErrorMessage(msg);

  const loadUsers = async () => {
    try {
      setUsersLoading(true);
      const list = await getUsers();
      setUsers(list);
    } catch (e) {
      const err = e as ApiError;
      showError(err.message || "Erro ao carregar utilizadores.");
    } finally {
      setUsersLoading(false);
    }
  };

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        const me = await getMe();
        setMeId(me.id);

        const isAdmin = me.role === "ADMIN";
        setAdminOk(isAdmin);

        if (isAdmin) await loadUsers();
      } catch (e) {
        const err = e as ApiError;
        setAdminOk(false);
        setErrorMessage(err.message || "Erro ao validar permissões.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const filteredUsers = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return users;

    return users.filter((u) => {
      const a = (u.username || "").toLowerCase();
      const b = (u.fullName || "").toLowerCase();
      const c = (u.email || "").toLowerCase();
      return a.includes(q) || b.includes(q) || c.includes(q) || String(u.id).includes(q);
    });
  }, [users, search]);

  const openManageForUser = (u: UserSummary) => {
    if (meId !== null && u.id === meId) {
      showError("Para gerir a tua conta usa Ver perfil.");
      return;
    }

    setSelectedUser(u);
    setEditUsername(u.username || "");
    setEditEmail(u.email || "");
    setEditFullName(u.fullName || "");
    setEditRole(u.role);

    setResetNewPassword("");
    setManageOpen(true);
  };

  const doSaveUser = async () => {
    if (!selectedUser) return;

    const uErr = validateUsername(editUsername);
    if (uErr) return showError(uErr);

    const eErr = validateEmail(editEmail);
    if (eErr) return showError(eErr);

    const fErr = validateFullName(editFullName);
    if (fErr) return showError(fErr);

    try {
      setLoading(true);
      setErrorMessage(null);

      const payload = {
        username: editUsername.trim(),
        email: editEmail.trim() ? editEmail.trim() : null,
        fullName: editFullName.trim(),
        role: editRole,
      };

      const updated = await updateUser(selectedUser.id, payload);

      setUsers((prev) => prev.map((x) => (x.id === updated.id ? updated : x)));
      setSelectedUser(updated);

      Alert.alert("Sucesso", `Utilizador #${updated.id} atualizado.`);
    } catch (e) {
      const err = e as ApiError;
      showError(err.message || "Erro ao atualizar utilizador.");
    } finally {
      setLoading(false);
    }
  };

  const doActivate = async () => {
    if (!selectedUser) return;
    try {
      setLoading(true);
      setErrorMessage(null);

      const updated = await activateUser(selectedUser.id);
      setUsers((prev) => prev.map((x) => (x.id === updated.id ? updated : x)));
      setSelectedUser(updated);

      Alert.alert("Sucesso", `Utilizador #${updated.id} ativado.`);
    } catch (e) {
      const err = e as ApiError;
      showError(err.message || "Erro ao ativar utilizador.");
    } finally {
      setLoading(false);
    }
  };

  const doDeactivate = async () => {
    if (!selectedUser) return;
    try {
      setLoading(true);
      setErrorMessage(null);

      const updated = await deactivateUser(selectedUser.id);
      setUsers((prev) => prev.map((x) => (x.id === updated.id ? updated : x)));
      setSelectedUser(updated);

      Alert.alert("Sucesso", `Utilizador #${updated.id} desativado.`);
    } catch (e) {
      const err = e as ApiError;
      showError(err.message || "Erro ao desativar utilizador.");
    } finally {
      setLoading(false);
    }
  };

  const handleResetPress = async () => {
    if (!selectedUser) return;

    const pwErr = validateStrongPassword(resetNewPassword);
    if (pwErr) {
      setResetPressed(false);
      return showError(pwErr);
    }

    try {
      setLoading(true);
      setErrorMessage(null);

      await adminResetPassword({ userId: selectedUser.id, newPassword: resetNewPassword });

      Alert.alert("Sucesso", `Password resetada para utilizador #${selectedUser.id}.`);
      setResetNewPassword("");
    } catch (e) {
      const err = e as ApiError;
      showError(err.message || "Erro ao resetar password.");
    } finally {
      setLoading(false);
      setResetPressed(false);
    }
  };

  const doCreateUser = async () => {
    const uErr = validateUsername(username);
    if (uErr) return showError(uErr);

    const eErr = validateEmail(email);
    if (eErr) return showError(eErr);

    const fErr = validateFullName(fullName);
    if (fErr) return showError(fErr);

    const pwErr = validateStrongPassword(password);
    if (pwErr) return showError(pwErr);

    try {
      setLoading(true);
      setErrorMessage(null);

      const body = {
        username: username.trim(),
        email: email.trim() || undefined,
        fullName: fullName.trim(),
        password: password.trim(),
        role,
      };

      const newUser = await registerUser(body);

      Alert.alert("Sucesso", `Utilizador #${newUser.id} criado com sucesso!`);

      setUsername("");
      setEmail("");
      setFullName("");
      setPassword("");
      setRole("CLIENT");
      setCreateOpen(false);

      await loadUsers();
    } catch (e) {
      const err = e as ApiError;
      showError(err.message || "Erro ao criar utilizador.");
    } finally {
      setLoading(false);
    }
  };

  // LOADING INICIAL
  if (loading && adminOk === null) {
    return (
      <SafeAreaView className="flex-1 bg-white">
        <View className="flex-1 justify-center items-center">
          <ActivityIndicator size="large" color="#2563eb" />
          <Text className="text-gray-600 mt-4">A verificar permissões...</Text>
        </View>
      </SafeAreaView>
    );
  }

  // NÃO É ADMIN
  if (adminOk === false) {
    return (
      <SafeAreaView className="flex-1 bg-white">
        {/* Header Simples */}
        <View className="bg-white px-4 py-3 border-b border-gray-200">
          <View className="flex-row items-center">
            <TouchableOpacity onPress={handleBack} hitSlop={10}>
              <Ionicons name="arrow-back" size={24} color="#111827" />
            </TouchableOpacity>
            <Text className="ml-3 text-xl font-bold text-gray-900">Utilizadores</Text>
          </View>
        </View>

        <View className="flex-1 justify-center items-center px-6">
          <Ionicons name="lock-closed-outline" size={80} color="#ef4444" />
          <Text className="text-red-600 text-xl font-bold mt-4 text-center">Acesso negado</Text>
          <Text className="text-gray-600 text-center mt-2">
            Apenas administradores podem aceder a esta página.
          </Text>
          {errorMessage && (
            <View className="mt-4 bg-red-50 rounded-xl p-4 w-full">
              <Text className="text-red-700 text-sm">{errorMessage}</Text>
            </View>
          )}
          <TouchableOpacity
            className="mt-6 bg-blue-500 px-6 py-3 rounded-xl"
            onPress={handleBack}
          >
            <Text className="text-white font-semibold">Voltar</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // ADMIN OK
  return (
    <SafeAreaView className="flex-1 bg-white">
      {/* Header Simples */}
      <View className="bg-white px-4 py-3 border-b border-gray-200">
        <View className="flex-row items-center justify-between">
          <View className="flex-row items-center">
            <TouchableOpacity onPress={handleBack} hitSlop={10}>
              <Ionicons name="arrow-back" size={24} color="#111827" />
            </TouchableOpacity>
            <Text className="ml-3 text-xl font-bold text-gray-900">Utilizadores</Text>
          </View>
          <TouchableOpacity onPress={() => loadUsers()} hitSlop={10}>
            <Ionicons name="refresh" size={24} color="#2563eb" />
          </TouchableOpacity>
        </View>
      </View>

      {/* ERROR MESSAGE */}
      {errorMessage && (
        <View className="mx-4 mt-3 bg-red-50 border border-red-200 rounded-xl p-4">
          <View className="flex-row items-center">
            <Ionicons name="alert-circle" size={20} color="#ef4444" />
            <Text className="ml-2 text-red-600 font-medium flex-1">{errorMessage}</Text>
            <TouchableOpacity onPress={() => setErrorMessage(null)}>
              <Ionicons name="close" size={20} color="#ef4444" />
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* SEARCH BAR */}
      <View className="mx-4 mt-4">
        <View className="flex-row items-center bg-gray-100 rounded-xl px-4 py-3">
          <Ionicons name="search-outline" size={20} color="#6b7280" />
          <TextInput
            className="flex-1 ml-2 text-gray-900"
            placeholder="Pesquisar por ID, username, email ou nome..."
            placeholderTextColor="#9ca3af"
            value={search}
            onChangeText={setSearch}
          />
          {search.length > 0 && (
            <TouchableOpacity onPress={() => setSearch("")} hitSlop={10}>
              <Ionicons name="close-circle" size={20} color="#6b7280" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* USERS LIST */}
      <View className="flex-1 mt-4 px-4">
        {usersLoading ? (
          <View className="flex-1 justify-center items-center">
            <ActivityIndicator size="large" color="#2563eb" />
            <Text className="text-gray-600 mt-4">A carregar utilizadores...</Text>
          </View>
        ) : filteredUsers.length === 0 ? (
          <View className="flex-1 justify-center items-center">
            <Ionicons name="people-outline" size={64} color="#9ca3af" />
            <Text className="text-gray-400 text-center mt-4 text-lg">
              {search.trim() ? "Nenhum utilizador encontrado" : "Nenhum utilizador na base de dados"}
            </Text>
          </View>
        ) : (
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 80 }}>
            {filteredUsers.map((u) => {
              const isCurrentUser = meId !== null && u.id === meId;
              return (
                <TouchableOpacity
                  key={u.id}
                  className={`mb-3 p-4 rounded-xl border ${
                    isCurrentUser
                      ? "bg-blue-50 border-blue-300"
                      : u.isActive
                      ? "bg-white border-gray-200"
                      : "bg-gray-50 border-gray-300"
                  }`}
                  onPress={() => openManageForUser(u)}
                  disabled={isCurrentUser}
                >
                  <View className="flex-row items-center justify-between">
                    <View className="flex-1">
                      <View className="flex-row items-center">
                        <Text className="text-gray-900 font-bold text-base">{u.fullName}</Text>
                        {isCurrentUser && (
                          <View className="ml-2 bg-blue-500 px-2 py-1 rounded">
                            <Text className="text-white text-xs font-semibold">TU</Text>
                          </View>
                        )}
                      </View>
                      <Text className="text-gray-600 text-sm mt-1">@{u.username}</Text>
                      {u.email && <Text className="text-gray-500 text-sm">{u.email}</Text>}
                      <View className="flex-row items-center mt-2">
                        <View
                          className={`px-2 py-1 rounded ${
                            u.role === "ADMIN"
                              ? "bg-purple-100"
                              : u.role === "SALES"
                              ? "bg-green-100"
                              : u.role === "WAREHOUSE"
                              ? "bg-orange-100"
                              : "bg-gray-100"
                          }`}
                        >
                          <Text
                            className={`text-xs font-semibold ${
                              u.role === "ADMIN"
                                ? "text-purple-700"
                                : u.role === "SALES"
                                ? "text-green-700"
                                : u.role === "WAREHOUSE"
                                ? "text-orange-700"
                                : "text-gray-700"
                            }`}
                          >
                            {u.role}
                          </Text>
                        </View>
                        <View
                          className={`ml-2 px-2 py-1 rounded ${
                            u.isActive ? "bg-green-100" : "bg-red-100"
                          }`}
                        >
                          <Text
                            className={`text-xs font-semibold ${
                              u.isActive ? "text-green-700" : "text-red-700"
                            }`}
                          >
                            {u.isActive ? "ATIVO" : "INATIVO"}
                          </Text>
                        </View>
                      </View>
                    </View>
                    {!isCurrentUser && (
                      <Ionicons name="chevron-forward" size={20} color="#9ca3af" />
                    )}
                  </View>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        )}
      </View>

      {/* FAB: Criar utilizador */}
      <TouchableOpacity
        className="absolute bottom-6 right-6 bg-blue-500 w-14 h-14 rounded-full items-center justify-center shadow-lg"
        onPress={() => setCreateOpen(true)}
        activeOpacity={0.8}
      >
        <Ionicons name="add" size={28} color="#fff" />
      </TouchableOpacity>

      {/* MODAL: Gerir utilizador */}
      <Modal
        visible={manageOpen}
        transparent
        animationType="slide"
        onRequestClose={() => setManageOpen(false)}
      >
        <View className="flex-1 justify-end" style={{ backgroundColor: "rgba(0,0,0,0.35)" }}>
          <View className="bg-white rounded-t-3xl p-4 max-h-[88%]">
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <Ionicons name="person-circle-outline" size={20} color="#111827" />
                <Text className="ml-2 text-gray-900 font-bold text-base">
                  Gerir utilizador #{selectedUser?.id}
                </Text>
              </View>
              <Pressable onPress={() => setManageOpen(false)} hitSlop={10}>
                <Ionicons name="close" size={20} color="#111827" />
              </Pressable>
            </View>

            <ScrollView
              keyboardShouldPersistTaps="always"
              className="mt-3"
              contentContainerStyle={{ paddingBottom: 24 }}
            >
              {/* ACTIVATE / DEACTIVATE */}
              <View className="bg-gray-100 rounded-2xl p-4">
                <View className="flex-row items-center justify-between">
                  <View className="flex-row items-center">
                    <Ionicons
                      name={selectedUser?.isActive ? "checkmark-circle" : "close-circle"}
                      size={18}
                      color={selectedUser?.isActive ? "#10b981" : "#ef4444"}
                    />
                    <Text className="ml-2 text-gray-900 font-bold">
                      Estado: {selectedUser?.isActive ? "ATIVO" : "INATIVO"}
                    </Text>
                  </View>
                  {selectedUser?.isActive ? (
                    <TouchableOpacity
                      onPress={() => void doDeactivate()}
                      disabled={loading}
                      className="bg-red-500 px-3 py-2 rounded-lg"
                      style={{ opacity: loading ? 0.6 : 1 }}
                    >
                      <Text className="text-white font-bold text-xs">
                        {loading ? "..." : "Desativar"}
                      </Text>
                    </TouchableOpacity>
                  ) : (
                    <TouchableOpacity
                      onPress={() => void doActivate()}
                      disabled={loading}
                      className="bg-green-500 px-3 py-2 rounded-lg"
                      style={{ opacity: loading ? 0.6 : 1 }}
                    >
                      <Text className="text-white font-bold text-xs">
                        {loading ? "..." : "Ativar"}
                      </Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>

              {/* EDIT FORM */}
              <View className="mt-4 bg-gray-100 rounded-2xl p-4">
                <View className="flex-row items-center">
                  <Ionicons name="create-outline" size={18} color="#111827" />
                  <Text className="ml-2 text-gray-900 font-bold">Editar dados</Text>
                </View>

                <Text className="text-gray-700 mt-4 font-semibold">Username</Text>
                <TextInput
                  className="mt-2 bg-white rounded-xl px-3 py-2 text-gray-900 border border-gray-200"
                  value={editUsername}
                  onChangeText={setEditUsername}
                  placeholder="ex: jose_silva"
                  placeholderTextColor="#9ca3af"
                  autoCapitalize="none"
                />

                <Text className="text-gray-700 mt-4 font-semibold">Email (opcional)</Text>
                <TextInput
                  className="mt-2 bg-white rounded-xl px-3 py-2 text-gray-900 border border-gray-200"
                  value={editEmail}
                  onChangeText={setEditEmail}
                  placeholder="ex: jose@example.com (pode ficar vazio)"
                  placeholderTextColor="#9ca3af"
                  autoCapitalize="none"
                  keyboardType="email-address"
                />

                <Text className="text-gray-700 mt-4 font-semibold">Full name</Text>
                <TextInput
                  className="mt-2 bg-white rounded-xl px-3 py-2 text-gray-900 border border-gray-200"
                  value={editFullName}
                  onChangeText={setEditFullName}
                  placeholder="ex: José Silva"
                  placeholderTextColor="#9ca3af"
                />

                <Text className="text-gray-700 mt-4 font-semibold">Role</Text>
                <View className="flex-row flex-wrap mt-2">
                  {roleOptions.map((r) => (
                    <Pressable
                      key={r}
                      onPress={() => setEditRole(r)}
                      style={{
                        marginRight: 8,
                        marginBottom: 8,
                        paddingHorizontal: 12,
                        paddingVertical: 10,
                        borderRadius: 12,
                        borderWidth: 1,
                        borderColor: editRole === r ? "#2563eb" : "#d1d5db",
                        backgroundColor: editRole === r ? "#2563eb" : "#ffffff",
                      }}
                    >
                      <Text style={{ color: editRole === r ? "white" : "#111827", fontWeight: "600" }}>
                        {r}
                      </Text>
                    </Pressable>
                  ))}
                </View>

                <TouchableOpacity
                  onPress={() => void doSaveUser()}
                  disabled={loading}
                  className="mt-4 bg-blue-500 rounded-xl py-3.5 items-center"
                  style={{ opacity: loading ? 0.6 : 1 }}
                >
                  <Text className="text-white font-bold text-base">
                    {loading ? "A guardar..." : "Guardar alterações"}
                  </Text>
                </TouchableOpacity>

                <Text className="text-gray-500 text-xs mt-2">
                  Regras: username 3-30 (letters/numbers/_), email válido (máx: 255), fullName 2-100.
                </Text>
              </View>

              {/* RESET PASSWORD */}
              <View className="mt-4 bg-gray-100 rounded-2xl p-4">
                <View className="flex-row items-center">
                  <Ionicons name="key-outline" size={18} color="#111827" />
                  <Text className="ml-2 text-gray-900 font-bold">Reset password</Text>
                </View>

                <Text className="text-gray-700 mt-4 font-semibold">Nova password</Text>
                <TextInput
                  className="mt-2 bg-white rounded-xl px-3 py-2 text-gray-900 border border-gray-200"
                  value={resetNewPassword}
                  onChangeText={setResetNewPassword}
                  placeholder="Ex: NewSecurePass789"
                  placeholderTextColor="#9ca3af"
                  secureTextEntry
                />

                <Text className="text-gray-500 text-xs mt-2">
                  Regras: 6-100 caracteres, pelo menos 1 minúscula, 1 maiúscula e 1 número.
                </Text>

                <TouchableOpacity
                  onPressIn={() => setResetPressed(true)}
                  onPress={handleResetPress}
                  disabled={loading}
                  className="mt-4 bg-blue-500 rounded-xl py-3.5 items-center"
                  style={{ opacity: loading ? 0.6 : 1 }}
                >
                  <Text className="text-white font-bold text-base">
                    {loading ? "A processar..." : resetPressed ? "A clicar..." : "Reset password"}
                  </Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* MODAL: Criar utilizador */}
      <Modal
        visible={createOpen}
        transparent
        animationType="slide"
        onRequestClose={() => setCreateOpen(false)}
      >
        <View className="flex-1 justify-end" style={{ backgroundColor: "rgba(0,0,0,0.35)" }}>
          <View className="bg-white rounded-t-3xl p-4 max-h-[88%]">
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <Ionicons name="person-add-outline" size={20} color="#111827" />
                <Text className="ml-2 text-gray-900 font-bold text-base">Criar utilizador</Text>
              </View>
              <Pressable onPress={() => setCreateOpen(false)} hitSlop={10}>
                <Ionicons name="close" size={20} color="#111827" />
              </Pressable>
            </View>

            <ScrollView
              keyboardShouldPersistTaps="always"
              className="mt-3"
              contentContainerStyle={{ paddingBottom: 24 }}
            >
              <Text className="text-gray-700 mt-2 font-semibold">Username</Text>
              <TextInput
                className="mt-2 bg-white rounded-xl px-3 py-2 text-gray-900 border border-gray-200"
                value={username}
                onChangeText={setUsername}
                placeholder="ex: jose_silva"
                placeholderTextColor="#9ca3af"
                autoCapitalize="none"
              />

              <Text className="text-gray-700 mt-4 font-semibold">Email (opcional)</Text>
              <TextInput
                className="mt-2 bg-white rounded-xl px-3 py-2 text-gray-900 border border-gray-200"
                value={email}
                onChangeText={setEmail}
                placeholder="ex: jose@example.com"
                placeholderTextColor="#9ca3af"
                autoCapitalize="none"
                keyboardType="email-address"
              />

              <Text className="text-gray-700 mt-4 font-semibold">Full name</Text>
              <TextInput
                className="mt-2 bg-white rounded-xl px-3 py-2 text-gray-900 border border-gray-200"
                value={fullName}
                onChangeText={setFullName}
                placeholder="ex: José Silva"
                placeholderTextColor="#9ca3af"
              />

              <Text className="text-gray-700 mt-4 font-semibold">Password</Text>
              <TextInput
                className="mt-2 bg-white rounded-xl px-3 py-2 text-gray-900 border border-gray-200"
                value={password}
                onChangeText={setPassword}
                placeholder="ex: UserPass123"
                placeholderTextColor="#9ca3af"
                secureTextEntry
              />

              <Text className="text-gray-700 mt-4 font-semibold">Role</Text>
              <View className="flex-row flex-wrap mt-2">
                {roleOptions.map((r) => (
                  <Pressable
                    key={r}
                    onPress={() => setRole(r)}
                    style={{
                      marginRight: 8,
                      marginBottom: 8,
                      paddingHorizontal: 12,
                      paddingVertical: 10,
                      borderRadius: 12,
                      borderWidth: 1,
                      borderColor: role === r ? "#2563eb" : "#d1d5db",
                      backgroundColor: role === r ? "#2563eb" : "#ffffff",
                    }}
                  >
                    <Text style={{ color: role === r ? "white" : "#111827", fontWeight: "600" }}>{r}</Text>
                  </Pressable>
                ))}
              </View>

              <TouchableOpacity
                onPress={() => void doCreateUser()}
                disabled={loading}
                className="mt-4 bg-blue-500 rounded-xl py-3.5 items-center"
                style={{ opacity: loading ? 0.6 : 1 }}
              >
                <Text className="text-white font-bold text-base">
                  {loading ? "A processar..." : "Criar utilizador"}
                </Text>
              </TouchableOpacity>

              <Text className="text-gray-500 text-xs mt-3 text-center">
                Preenche todos os campos obrigatórios para criar o utilizador.
              </Text>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}