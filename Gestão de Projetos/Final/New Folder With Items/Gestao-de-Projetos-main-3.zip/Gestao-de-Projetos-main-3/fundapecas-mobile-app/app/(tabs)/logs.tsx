import { useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  TextInput,
  RefreshControl,
  LayoutAnimation,
  Platform,
  UIManager,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import Header from "../(shared)/Header";
import { router } from "expo-router";
import { ApiError } from "../(services)/authService";
import {
  AuditLog,
  getAuditLogById,
  getAuditLogs,
  PaginatedAuditLogsResponse,
} from "../(services)/auditLogService";

if (Platform.OS === "android" && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

export default function AdminLogsScreen() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Filtros (inclui logId, mas não é uma barra separada)
  const [logId, setLogId] = useState("");
  const [userId, setUserId] = useState("");
  const [action, setAction] = useState("");
  const [entity, setEntity] = useState("");
  const [entityId, setEntityId] = useState("");
  const [search, setSearch] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  // Paginação
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const handleProfilePress = () => router.push("/profile");
  const handleLogoutPress = () => router.replace("/login");
  const handleBack = () => router.back();

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return iso;
    return d.toLocaleString();
  };

  const formatApiErrorMessage = (e: unknown) => {
    const err = e as (ApiError & { details?: any });
    const base = err?.message || "Erro ao carregar logs.";

    if (err?.details) {
      try {
        const detailStr =
          typeof err.details === "string" ? err.details : JSON.stringify(err.details, null, 2);
        return `${base}\n\nDetalhes:\n${detailStr}`;
      } catch {
        return base;
      }
    }

    return base;
  };

  const parsePositiveIntOrUndefined = (value: string, label: string) => {
    const trimmed = value.trim();
    if (!trimmed) return undefined;
    const n = Number(trimmed);
    if (!Number.isInteger(n) || n <= 0) {
      throw new Error(`${label} inválido. Usa um número inteiro positivo.`);
    }
    return n;
  };

  const hasAnyFilter = useMemo(() => {
    return Boolean(
      logId.trim() ||
        userId.trim() ||
        action.trim() ||
        entity.trim() ||
        entityId.trim() ||
        search.trim() ||
        dateFrom.trim() ||
        dateTo.trim()
    );
  }, [logId, userId, action, entity, entityId, search, dateFrom, dateTo]);

  const loadList = async (targetPage: number, opts?: { silent?: boolean }) => {
    try {
      if (!opts?.silent) setLoading(true);
      setErrorMessage(null);

      const uid = parsePositiveIntOrUndefined(userId, "userId");

      const data: PaginatedAuditLogsResponse = await getAuditLogs({
        page: targetPage,
        pageSize,
        userId: uid,
        action: action.trim() || undefined,
        entity: entity.trim() || undefined,
        entityId: entityId.trim() || undefined,
        search: search.trim() || undefined,
        dateFrom: dateFrom.trim() || undefined,
        dateTo: dateTo.trim() || undefined,
      });

      setLogs(data.items);
      setTotal(data.total);
      setPage(data.page);
      setTotalPages(data.totalPages);
    } catch (e) {
      const msg =
        e instanceof Error && e.message.includes("inválido")
          ? e.message
          : formatApiErrorMessage(e);

      setErrorMessage(msg);
      setLogs([]);
      setTotal(0);
      setTotalPages(1);
    } finally {
      if (!opts?.silent) setLoading(false);
    }
  };

  const clearFilters = () => {
    setLogId("");
    setUserId("");
    setAction("");
    setEntity("");
    setEntityId("");
    setSearch("");
    setDateFrom("");
    setDateTo("");
  };

  const handleApply = async () => {
    // Se logId vier preenchido, usamos /audit-logs/:id
    const trimmedId = logId.trim();
    if (trimmedId) {
      const id = parsePositiveIntOrUndefined(trimmedId, "ID do log");
      if (!id) return;

      try {
        setLoading(true);
        setErrorMessage(null);

        const one = await getAuditLogById(id);
        setLogs([one]);
        setTotal(1);
        setPage(1);
        setTotalPages(1);

        // opcional: recolher filtros depois de aplicar
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        setFiltersOpen(false);
      } catch (e) {
        setErrorMessage(formatApiErrorMessage(e));
        setLogs([]);
        setTotal(0);
        setTotalPages(1);
      } finally {
        setLoading(false);
      }

      return;
    }

    // Caso contrário, faz listagem normal com filtros
    await loadList(1);

    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setFiltersOpen(false);
  };

  const handleReset = async () => {
    clearFilters();
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setFiltersOpen(false);
    await loadList(1);
  };

  useEffect(() => {
    loadList(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const title = useMemo(() => {
    return hasAnyFilter ? "Logs (filtrados)" : "Logs de Auditoria";
  }, [hasAnyFilter]);

  const toggleFilters = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setFiltersOpen((v) => !v);
  };

  return (
    <SafeAreaView className="flex-1 bg-white">
      <Header onProfilePress={handleProfilePress} onLogoutPress={handleLogoutPress} />

      {/* Barra de cabeçalho com botão voltar */}
      <View className="flex-row items-center justify-between px-4 py-3 bg-white border-b border-gray-200">
        <TouchableOpacity onPress={handleBack} className="flex-row items-center">
          <Ionicons name="arrow-back" size={24} color="#111827" />
          <Text className="ml-2 text-base text-gray-900 font-medium">Voltar</Text>
        </TouchableOpacity>
      </View>

      <View className="px-4 pt-4">
        <View className="flex-row items-start justify-between">
          <View className="flex-1 pr-3">
            <Text className="text-xl font-bold text-gray-900">{title}</Text>
            <Text className="text-gray-500 mt-1">
              Página {page} / {totalPages} • Total: {total}
            </Text>
          </View>

          <TouchableOpacity
            className="bg-gray-100 border border-gray-200 rounded-2xl px-3 py-2 flex-row items-center"
            onPress={toggleFilters}
            disabled={loading}
          >
            <Ionicons name="options-outline" size={18} color="#111827" />
            <Text className="ml-2 text-gray-900 font-semibold">
              {filtersOpen ? "Fechar" : "Filtros"}
            </Text>
            <Ionicons
              name={filtersOpen ? "chevron-up" : "chevron-down"}
              size={18}
              color="#111827"
              style={{ marginLeft: 6 }}
            />
          </TouchableOpacity>
        </View>

        {/* Card dos filtros (colapsável) */}
        {filtersOpen && (
          <View className="mt-3 bg-gray-50 border border-gray-200 rounded-2xl p-4">
            <Text className="text-gray-900 font-semibold mb-3">Filtros</Text>

            {/* Linha 1 */}
            <View className="flex-row gap-2">
              <View className="flex-1">
                <Text className="text-gray-600 text-xs mb-1">ID do log (/:id)</Text>
                <TextInput
                  className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-gray-800"
                  placeholder="Ex: 12"
                  placeholderTextColor="#9ca3af"
                  keyboardType="numeric"
                  value={logId}
                  onChangeText={setLogId}
                />
              </View>

              <View className="flex-1">
                <Text className="text-gray-600 text-xs mb-1">userId</Text>
                <TextInput
                  className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-gray-800"
                  placeholder="Ex: 1"
                  placeholderTextColor="#9ca3af"
                  keyboardType="numeric"
                  value={userId}
                  onChangeText={setUserId}
                />
              </View>
            </View>

            {/* Linha 2 */}
            <View className="flex-row gap-2 mt-3">
              <View className="flex-1">
                <Text className="text-gray-600 text-xs mb-1">action</Text>
                <TextInput
                  className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-gray-800"
                  placeholder="Ex: PART"
                  placeholderTextColor="#9ca3af"
                  value={action}
                  onChangeText={setAction}
                  autoCapitalize="characters"
                />
              </View>

              <View className="flex-1">
                <Text className="text-gray-600 text-xs mb-1">entity</Text>
                <TextInput
                  className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-gray-800"
                  placeholder="Ex: PART"
                  placeholderTextColor="#9ca3af"
                  value={entity}
                  onChangeText={setEntity}
                  autoCapitalize="characters"
                />
              </View>

              <View className="flex-1">
                <Text className="text-gray-600 text-xs mb-1">entityId</Text>
                <TextInput
                  className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-gray-800"
                  placeholder="Ex: TEST-001"
                  placeholderTextColor="#9ca3af"
                  value={entityId}
                  onChangeText={setEntityId}
                  autoCapitalize="none"
                />
              </View>
            </View>

            {/* Linha 3 */}
            <View className="mt-3">
              <Text className="text-gray-600 text-xs mb-1">search</Text>
              <TextInput
                className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-gray-800"
                placeholder="Ex: TEST-001"
                placeholderTextColor="#9ca3af"
                value={search}
                onChangeText={setSearch}
                autoCapitalize="none"
              />
            </View>

            {/* Linha 4 */}
            <View className="flex-row gap-2 mt-3">
              <View className="flex-1">
                <Text className="text-gray-600 text-xs mb-1">dateFrom (ISO)</Text>
                <TextInput
                  className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-gray-800"
                  placeholder="2025-12-31T00:00:00.000Z"
                  placeholderTextColor="#9ca3af"
                  value={dateFrom}
                  onChangeText={setDateFrom}
                  autoCapitalize="none"
                />
              </View>

              <View className="flex-1">
                <Text className="text-gray-600 text-xs mb-1">dateTo (ISO)</Text>
                <TextInput
                  className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-gray-800"
                  placeholder="2026-01-02T23:59:59.000Z"
                  placeholderTextColor="#9ca3af"
                  value={dateTo}
                  onChangeText={setDateTo}
                  autoCapitalize="none"
                />
              </View>
            </View>

            {/* Botões */}
            <View className="flex-row mt-4">
              <TouchableOpacity
                className="flex-1 bg-blue-600 rounded-xl py-3 items-center mr-2"
                onPress={handleApply}
                disabled={loading}
              >
                <Text className="text-white font-semibold">Aplicar</Text>
              </TouchableOpacity>

              <TouchableOpacity
                className="flex-1 bg-white border border-gray-300 rounded-xl py-3 items-center ml-2"
                onPress={handleReset}
                disabled={loading}
              >
                <Text className="text-gray-900 font-semibold">Limpar</Text>
              </TouchableOpacity>
            </View>

            <Text className="text-gray-500 text-xs mt-3">
              Dica: se preencheres "ID do log", a pesquisa usa /audit-logs/:id e ignora os restantes filtros.
            </Text>
          </View>
        )}

        {/* Erros */}
        {errorMessage && (
          <View className="mt-3 bg-red-50 border border-red-200 rounded-2xl p-4">
            <View className="flex-row items-start">
              <Ionicons name="alert-circle" size={20} color="#ef4444" />
              <Text className="ml-2 text-red-700 font-medium flex-1">{errorMessage}</Text>
              <TouchableOpacity onPress={() => setErrorMessage(null)}>
                <Ionicons name="close" size={20} color="#ef4444" />
              </TouchableOpacity>
            </View>
          </View>
        )}
      </View>

      {/* Lista */}
      <View className="flex-1 px-4 mt-4">
        {loading ? (
          <View className="flex-1 items-center justify-center">
            <ActivityIndicator size="large" />
            <Text className="text-gray-500 mt-3">A carregar logs...</Text>
          </View>
        ) : logs.length === 0 ? (
          <View className="flex-1 items-center justify-center">
            <Ionicons name="document-text-outline" size={64} color="#9ca3af" />
            <Text className="text-gray-400 text-center mt-4 text-lg">Sem logs para mostrar</Text>

            <TouchableOpacity className="mt-5 bg-blue-600 rounded-xl px-5 py-3" onPress={() => loadList(1)}>
              <Text className="text-white font-semibold">Recarregar</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            {/* Paginação */}
            <View className="flex-row items-center justify-between mb-3">
              <Text className="text-gray-500 text-xs">
              </Text>

              <View className="flex-row">
                <TouchableOpacity
                  className={`rounded-xl px-3 py-2 mr-2 ${page <= 1 ? "bg-gray-100" : "bg-gray-200"}`}
                  onPress={() => loadList(Math.max(1, page - 1))}
                  disabled={loading || page <= 1}
                >
                  <Text className="text-gray-900">Anterior</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  className={`rounded-xl px-3 py-2 ${page >= totalPages ? "bg-gray-100" : "bg-gray-200"}`}
                  onPress={() => loadList(Math.min(totalPages, page + 1))}
                  disabled={loading || page >= totalPages}
                >
                  <Text className="text-gray-900">Próxima</Text>
                </TouchableOpacity>
              </View>
            </View>

            <FlatList
              data={logs}
              keyExtractor={(item) => item.id.toString()}
              refreshControl={
                <RefreshControl
                  refreshing={refreshing}
                  onRefresh={async () => {
                    setRefreshing(true);
                    await loadList(page, { silent: true });
                    setRefreshing(false);
                  }}
                />
              }
              renderItem={({ item }) => (
                <View className="bg-white border border-gray-200 rounded-2xl p-4 mb-3 shadow-sm">
                  <View className="flex-row items-center justify-between">
                    <Text className="text-gray-900 font-bold text-base">
                      #{item.id} • {item.action}
                    </Text>
                    <Text className="text-gray-500 text-xs">{formatDate(item.timestamp)}</Text>
                  </View>

                  <View className="mt-2">
                    <Text className="text-gray-700">
                      <Text className="font-semibold">Entidade:</Text> {item.entity}
                    </Text>
                    <Text className="text-gray-700 mt-1">
                      <Text className="font-semibold">EntityId:</Text> {item.entityId ?? "N/A"}
                    </Text>
                    <Text className="text-gray-700 mt-1">
                      <Text className="font-semibold">User:</Text>{" "}
                      {item.user?.username ?? item.userId ?? "N/A"}
                    </Text>
                  </View>

                  {item.details !== undefined && (
                    <View className="mt-3 bg-gray-50 border border-gray-200 rounded-xl p-3">
                      <Text className="text-gray-700 font-semibold mb-1">Details</Text>
                      <Text className="text-gray-600 text-xs">
                        {typeof item.details === "string"
                          ? item.details
                          : JSON.stringify(item.details, null, 2)}
                      </Text>
                    </View>
                  )}
                </View>
              )}
              showsVerticalScrollIndicator={false}
            />
          </>
        )}
      </View>
    </SafeAreaView>
  );
}