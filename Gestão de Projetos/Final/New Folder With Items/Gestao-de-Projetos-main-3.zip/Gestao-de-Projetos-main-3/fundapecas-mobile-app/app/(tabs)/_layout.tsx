import { Tabs } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useState, useEffect } from "react";
import { getMe } from "../(services)/authService";

export default function TabsLayout() {
    const [userRole, setUserRole] = useState<string | null>(null);

    useEffect(() => {
        loadUserRole();
    }, []);

    const loadUserRole = async () => {
        try {
            const me = await getMe();
            setUserRole(me.role);
        } catch (error) {
            console.error('Erro ao carregar role:', error);
            setUserRole(null);
        }
    };

    // ✅ Ocultar tab "Pedidos" se for CLIENT
    const showOrdersTab = userRole !== 'CLIENT';

    return (
        <Tabs
            screenOptions={{
                headerShown: false,
                tabBarActiveTintColor: "#2563eb",
                tabBarInactiveTintColor: "#94a3b8",
                tabBarStyle: {
                    backgroundColor: "white",
                    borderTopWidth: 0.3,
                    height: 58,
                    paddingBottom: 5,
                },
            }}
        >
            <Tabs.Screen
                name="home"
                options={{
                    title: "Home",
                    tabBarIcon: ({ color, size }) => (
                        <Ionicons name="home-outline" color={color} size={size} />
                    ),
                }}
            />
            <Tabs.Screen
                name="parts"
                options={{
                    title: "Peças",
                    tabBarIcon: ({ color, size }) => (
                        <Ionicons name="cube-outline" color={color} size={size} />
                    ),
                }}
            />
            {/* ✅ Tab "Pedidos" - Oculta para CLIENT */}
            <Tabs.Screen
                name="orders"
                options={{
                    title: "Pedidos",
                    tabBarIcon: ({ color, size }) => (
                        <Ionicons name="clipboard-outline" color={color} size={size} />
                    ),
                    // ✅ Ocultar se for CLIENT
                    href: showOrdersTab ? undefined : null,
                }}
            />
            <Tabs.Screen
                name="profile"
                options={{
                    href: null,
                }}
            />
            <Tabs.Screen
                name="Parts/[id]"
                options={{
                    href: null,
                }}
            />
            <Tabs.Screen
                name="Parts/createPart"
                options={{
                    href: null,
                }}
            />
            <Tabs.Screen
                name="Orders/createOrder"
                options={{
                    href: null,
                }}
            />
            <Tabs.Screen
                name="Parts/movementPart"
                options={{
                    href: null,
                }}
            />
            <Tabs.Screen
                name="Parts/editPart"
                options={{
                    href: null,
                }}
            />
            <Tabs.Screen
                name="logs"
                options={{
                    href: null, 
                }}
            />
            <Tabs.Screen
                name="users"
                options={{ href: null }}
            />
            <Tabs.Screen
                name="Parts/SelectWarehouse"
                options={{
                    href: null,
                }}
            />
            <Tabs.Screen
                name="Parts/SelectLocation"
                options={{
                    href: null,
                }}
            />
            <Tabs.Screen
                name="Parts/SelectShelfPallet"
                options={{
                    href: null,
                }}
            />
            <Tabs.Screen
                name="Parts/SelectBoxLocation"
                options={{
                    href: null,
                }}
            />
        </Tabs>
    );
}