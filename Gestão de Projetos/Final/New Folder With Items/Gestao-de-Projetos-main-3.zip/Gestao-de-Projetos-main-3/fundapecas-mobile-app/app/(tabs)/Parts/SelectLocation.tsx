import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Alert,
    Image,
    ScrollView,
    Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Picker } from '@react-native-picker/picker';
import Header from '../../(shared)/Header';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SelectLocation = () => {
    const router = useRouter();
    const params = useLocalSearchParams();
    const warehouseId = Number(params.warehouseId);
    const warehouseName = params.warehouseName as string;
    
    // ✅ Capturar informação de edição
    const fromEdit = params.fromEdit === 'true';
    const partId = params.partId as string;
    
    const [selectedLocation, setSelectedLocation] = useState('');

    const isUpperWarehouse = warehouseId === 1;
    const isBoxWarehouse = warehouseId === 3;
    const isPavilhao2 = warehouseId === 4;

    const boxLocations = [
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
        'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
        'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
    ];

    const pavilhao2Locations = [
        '01', '02', '03', '04', '05', '06', '07', '08', '09', '10',
        '11', '12', '13', '14', '15'
    ];

    const upperWarehouseLocations = [
        'A01', 'A02', 'A03', 'A04', 'A05', 'A06',
        'B01', 'B02', 'B03', 'B04', 'B05', 'B06',
        'C01', 'C02', 'C03', 'C04', 'C05', 'C06', 'C07', 'C08', 'C09',
        'D01', 'D02', 'D03', 'D04', 'D05', 'D06', 'D07',
        'E01', 'E02', 'E03', 'E04', 'E05', 'E06', 'E07',
        'F01', 'F02', 'F03', 'F04', 'F05', 'F06', 'F07',
    ];

    const lowerWarehouseLocations = [
        'A01', 'A02', 'A03', 'A04', 'A05', 'A06', 'A07', 'A08', 'A09', 'A10',
        'A11', 'A12', 'A13', 'A14', 'A15', 'A16', 'A17',
        'B01', 'B02', 'B03', 'B04', 'B05', 'B06', 'B07', 'B08', 'B09',
        'B10', 'B11', 'B12', 'B13', 'B14', 'B15',
        'C01', 'C02', 'C03', 'C04', 'C05', 'C06', 'C07', 'C08', 'C09',
        'C10', 'C11', 'C12', 'C13', 'C14', 'C15',
        'D01', 'D02', 'D03', 'D04', 'D05', 'D06', 'D07', 'D08', 'D09',
        'D10', 'D11', 'D12', 'D13', 'D14', 'D15', 'D16',
    ];

    const handleLogoutPress = async () => {
        try {
            await AsyncStorage.removeItem('userToken');
            router.replace('/login');
        } catch (error) {
            console.error('Erro ao fazer logout:', error);
            Alert.alert('Erro', 'Não foi possível fazer logout');
        }
    };

    const handleBack = () => {
        router.push({
            pathname: '/Parts/SelectWarehouse',
            params: {
                fromEdit: fromEdit ? 'true' : 'false',
                partId: partId || '',
            },
        });
    };

    const getLocationIdByFullCode = async (fullCode: string): Promise<number | null> => {
        try {
            const API_URL = process.env.EXPO_PUBLIC_API_URL;
            const token = await AsyncStorage.getItem('userToken');

            const response = await fetch(`${API_URL}/warehouses/${warehouseId}/locations`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error('Erro ao buscar localizações');
            }

            const locations = await response.json();
            const location = locations.find((loc: any) => loc.fullCode === fullCode);
            
            if (location) {
                console.log('✅ Localização encontrada:', location);
                return location.id;
            } else {
                console.error('❌ Localização não encontrada para fullCode:', fullCode);
                return null;
            }
        } catch (error) {
            console.error('❌ Erro ao buscar ID da localização:', error);
            return null;
        }
    };

    const handleBoxSelect = async (box: string) => {
        setSelectedLocation(box);
        
        const fullCode = `CX-${box}`;
        
        try {
            const locationId = await getLocationIdByFullCode(fullCode);
            
            if (!locationId) {
                Alert.alert('Erro', 'Não foi possível encontrar a localização no sistema.');
                return;
            }
            
            // ✅ Redirecionar baseado em fromEdit
            if (fromEdit && partId) {
                router.replace({
                    pathname: `/Parts/editPart`,
                    params: {
                        id: partId,
                        selectedLocationId: locationId.toString(),
                        selectedLocationCode: fullCode,
                        selectedLocationCapacity: '0/10',
                    },
                });
            } else {
                router.replace({
                    pathname: '/Parts/createPart',
                    params: {
                        selectedLocationId: locationId.toString(),
                        selectedLocationCode: fullCode,
                        selectedLocationCapacity: '0/10',
                    },
                });
            }
        } catch (error) {
            console.error('❌ Erro ao processar seleção:', error);
            Alert.alert('Erro', 'Ocorreu um erro ao processar a seleção');
        }
    };

    const handleConfirmSelection = async () => {
        if (!selectedLocation) {
            Alert.alert('Atenção', 'Por favor, selecione uma localização');
            return;
        }

        if (isPavilhao2) {
            const fullCode = `PAV2-${selectedLocation}`;
            
            try {
                const locationId = await getLocationIdByFullCode(fullCode);
                
                if (!locationId) {
                    Alert.alert('Erro', 'Não foi possível encontrar a localização no sistema.');
                    return;
                }
                
                // ✅ Redirecionar baseado em fromEdit
                if (fromEdit && partId) {
                    router.replace({
                        pathname: `/Parts/editPart`,
                        params: {
                            id: partId,
                            selectedLocationId: locationId.toString(),
                            selectedLocationCode: fullCode,
                            selectedLocationCapacity: '0/10',
                        },
                    });
                } else {
                    router.replace({
                        pathname: '/Parts/createPart',
                        params: {
                            selectedLocationId: locationId.toString(),
                            selectedLocationCode: fullCode,
                            selectedLocationCapacity: '0/10',
                        },
                    });
                }
            } catch (error) {
                console.error('❌ Erro ao buscar localização:', error);
                Alert.alert('Erro', 'Ocorreu um erro ao processar a seleção');
            }
        } else {
            // ✅ Passar informação de edição para SelectShelfPallet
            router.replace({
                pathname: '/Parts/SelectShelfPallet',
                params: {
                    selectedLocationCode: selectedLocation,
                    warehouseName: warehouseName,
                    warehouseId: warehouseId,
                    fromEdit: fromEdit ? 'true' : 'false',
                    partId: partId || '',
                },
            });
        }
    };

    const renderPavilhao2Picker = () => (
        <Picker
            selectedValue={selectedLocation}
            onValueChange={(itemValue) => setSelectedLocation(itemValue)}
            style={styles.picker}
            mode="dropdown"
            itemStyle={Platform.OS === 'ios' ? styles.pickerItem : undefined}
        >
            <Picker.Item label="Selecione uma caixa..." value="" />
            
            <Picker.Item label="─── 01-10 ───" value="" enabled={false} />
            {['01', '02', '03', '04', '05', '06', '07', '08', '09', '10'].map(loc => (
                <Picker.Item key={loc} label={`  Caixa ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── 11-15 ───" value="" enabled={false} />
            {['11', '12', '13', '14', '15'].map(loc => (
                <Picker.Item key={loc} label={`  Caixa ${loc}`} value={loc} />
            ))}
        </Picker>
    );

    const renderUpperWarehousePicker = () => (
        <Picker
            selectedValue={selectedLocation}
            onValueChange={(itemValue) => setSelectedLocation(itemValue)}
            style={styles.picker}
            mode="dropdown"
            itemStyle={Platform.OS === 'ios' ? styles.pickerItem : undefined}
        >
            <Picker.Item label="Selecione uma localização..." value="" />
            
            <Picker.Item label="─── SECÇÃO A ───" value="" enabled={false} />
            {['A01', 'A02', 'A03', 'A04', 'A05', 'A06'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── SECÇÃO B ───" value="" enabled={false} />
            {['B01', 'B02', 'B03', 'B04', 'B05', 'B06'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── SECÇÃO C ───" value="" enabled={false} />
            {['C01', 'C02', 'C03', 'C04', 'C05', 'C06', 'C07', 'C08', 'C09'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── SECÇÃO D ───" value="" enabled={false} />
            {['D01', 'D02', 'D03', 'D04', 'D05', 'D06', 'D07'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── SECÇÃO E ───" value="" enabled={false} />
            {['E01', 'E02', 'E03', 'E04', 'E05', 'E06', 'E07'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── SECÇÃO F ───" value="" enabled={false} />
            {['F01', 'F02', 'F03', 'F04', 'F05', 'F06', 'F07'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
        </Picker>
    );

    const renderLowerWarehousePicker = () => (
        <Picker
            selectedValue={selectedLocation}
            onValueChange={(itemValue) => setSelectedLocation(itemValue)}
            style={styles.picker}
            mode="dropdown"
            itemStyle={Platform.OS === 'ios' ? styles.pickerItem : undefined}
        >
            <Picker.Item label="Selecione uma localização..." value="" />
            
            <Picker.Item label="─── SECÇÃO A ───" value="" enabled={false} />
            {['A01', 'A02', 'A03', 'A04', 'A05', 'A06', 'A07', 'A08', 'A09', 'A10',
              'A11', 'A12', 'A13', 'A14', 'A15', 'A16', 'A17'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── SECÇÃO B ───" value="" enabled={false} />
            {['B01', 'B02', 'B03', 'B04', 'B05', 'B06', 'B07', 'B08', 'B09',
              'B10', 'B11', 'B12', 'B13', 'B14', 'B15'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── SECÇÃO C ───" value="" enabled={false} />
            {['C01', 'C02', 'C03', 'C04', 'C05', 'C06', 'C07', 'C08', 'C09',
              'C10', 'C11', 'C12', 'C13', 'C14', 'C15'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
            
            <Picker.Item label="─── SECÇÃO D ───" value="" enabled={false} />
            {['D01', 'D02', 'D03', 'D04', 'D05', 'D06', 'D07', 'D08', 'D09',
              'D10', 'D11', 'D12', 'D13', 'D14', 'D15', 'D16'].map(loc => (
                <Picker.Item key={loc} label={`  ${loc}`} value={loc} />
            ))}
        </Picker>
    );

    if (isBoxWarehouse) {
        return (
            <SafeAreaView style={styles.container}>
                <Header onProfilePress={() => router.push('/profile')} onLogoutPress={handleLogoutPress} />
                
                <View style={styles.headerBar}>
                    <TouchableOpacity onPress={handleBack} style={styles.backButton}>
                        <Ionicons name="arrow-back" size={24} color="#111827" />
                        <Text style={styles.backText}>Voltar</Text>
                    </TouchableOpacity>
                    
                    <View style={styles.headerTitleContainer}>
                        <Text style={styles.headerTitle}>{warehouseName}</Text>
                        <Text style={styles.headerSubtitle}>Selecionar Caixa</Text>
                    </View>
                    
                    <View style={styles.placeholder} />
                </View>

                <ScrollView style={styles.content} contentContainerStyle={styles.contentContainer}>
                    <View style={styles.catalogContainer}>
                        <Text style={styles.catalogTitle}>Selecione uma Caixa:</Text>
                        <View style={styles.catalog}>
                            {boxLocations.map(box => {
                                const isSelected = selectedLocation === box;
                                return (
                                    <TouchableOpacity
                                        key={box}
                                        style={[styles.boxCard, isSelected && styles.boxCardSelected]}
                                        onPress={() => handleBoxSelect(box)}
                                        activeOpacity={0.7}
                                    >
                                        <View style={styles.boxIconContainer}>
                                            <Ionicons 
                                                name="cube" 
                                                size={32} 
                                                color={isSelected ? '#fff' : '#3b82f6'} 
                                            />
                                        </View>
                                        <Text style={[styles.boxLabel, isSelected && styles.boxLabelSelected]}>
                                            Caixa {box}
                                        </Text>
                                    </TouchableOpacity>
                                );
                            })}
                        </View>
                    </View>
                </ScrollView>
            </SafeAreaView>
        );
    }

    return (
        <SafeAreaView style={styles.container}>
            <Header onProfilePress={() => router.push('/profile')} onLogoutPress={handleLogoutPress} />
            
            <View style={styles.headerBar}>
                <TouchableOpacity onPress={handleBack} style={styles.backButton}>
                    <Ionicons name="arrow-back" size={24} color="#111827" />
                    <Text style={styles.backText}>Voltar</Text>
                </TouchableOpacity>
                
                <View style={styles.headerTitleContainer}>
                    <Text style={styles.headerTitle}>{warehouseName}</Text>
                    <Text style={styles.headerSubtitle}>Selecionar Localização</Text>
                </View>
                
                <View style={styles.placeholder} />
            </View>

            <ScrollView style={styles.content} contentContainerStyle={styles.contentContainer}>
                <View style={styles.imageContainer}>
                    <Image
                        source={
                            isPavilhao2 
                                ? require('../../../assets/images/Pav2.png')
                                : isUpperWarehouse 
                                    ? require('../../../assets/images/mainWarehouse.png')
                                    : require('../../../assets/images/lowerWarehouse.png')
                        }
                        style={styles.warehouseImage}
                        resizeMode="contain"
                    />
                </View>

                <View style={styles.selectorContainer}>
                    <Text style={styles.selectorLabel}>
                        {isPavilhao2 ? 'Selecione a Caixa:' : 'Selecione a Localização:'}
                    </Text>
                    
                    <View style={styles.pickerContainer}>
                        {isPavilhao2 ? renderPavilhao2Picker() :
                         isUpperWarehouse ? renderUpperWarehousePicker() : 
                         renderLowerWarehousePicker()}
                    </View>

                    {selectedLocation && (
                        <View style={styles.selectedInfo}>
                            <Ionicons name="checkmark-circle" size={20} color="#10b981" />
                            <Text style={styles.selectedText}>
                                {isPavilhao2 ? 'Caixa selecionada:' : 'Localização selecionada:'} {' '}
                                <Text style={styles.selectedCode}>
                                    {isPavilhao2 ? `Caixa ${selectedLocation}` : selectedLocation}
                                </Text>
                            </Text>
                        </View>
                    )}
                </View>

                <TouchableOpacity
                    style={[styles.confirmButton, !selectedLocation && styles.confirmButtonDisabled]}
                    onPress={handleConfirmSelection}
                    disabled={!selectedLocation}
                >
                    <Text style={styles.confirmButtonText}>
                        {isPavilhao2 ? 'Confirmar Caixa' : 'Confirmar Localização'}
                    </Text>
                    <Ionicons name="arrow-forward" size={20} color="#fff" />
                </TouchableOpacity>
            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f9fafb',
    },
    headerBar: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 16,
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderBottomColor: '#e5e7eb',
    },
    backButton: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        flex: 1,
    },
    backText: {
        fontSize: 16,
        color: '#111827',
        fontWeight: '500',
    },
    headerTitleContainer: {
        flex: 2,
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#111827',
    },
    headerSubtitle: {
        fontSize: 12,
        color: '#6b7280',
        marginTop: 2,
    },
    placeholder: {
        flex: 1,
    },
    content: {
        flex: 1,
    },
    contentContainer: {
        padding: 16,
    },
    imageContainer: {
        backgroundColor: '#fff',
        borderRadius: 12,
        padding: 16,
        marginBottom: 24,
        elevation: 2,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
    },
    warehouseImage: {
        width: '100%',
        height: 400,
    },
    selectorContainer: {
        backgroundColor: '#fff',
        borderRadius: 12,
        padding: 16,
        marginBottom: 16,
        elevation: 2,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
    },
    selectorLabel: {
        fontSize: 14,
        fontWeight: '600',
        color: '#111827',
        marginBottom: 8,
    },
    pickerContainer: {
        borderWidth: 1,
        borderColor: '#d1d5db',
        borderRadius: 8,
        backgroundColor: '#fff',
        ...Platform.select({
            ios: {
                minHeight: 150,
            },
            android: {
                height: 50,
            },
        }),
    },
    picker: {
        ...Platform.select({
            ios: {
                height: 150,
                marginVertical: -10,
            },
            android: {
                height: 50,
                color: '#111827',
            },
            default: {
                height: 45,
            },
        }),
    },
    pickerItem: {
        height: 150,
        fontSize: 16,
        color: '#111827',
    },
    selectedInfo: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        marginTop: 12,
        padding: 10,
        backgroundColor: '#d1fae5',
        borderRadius: 8,
    },
    selectedText: {
        fontSize: 13,
        color: '#065f46',
        flex: 1,
    },
    selectedCode: {
        fontWeight: '700',
        fontSize: 14,
    },
    confirmButton: {
        backgroundColor: '#3b82f6',
        borderRadius: 12,
        padding: 16,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        elevation: 2,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
    },
    confirmButtonDisabled: {
        backgroundColor: '#9ca3af',
        opacity: 0.5,
    },
    confirmButtonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '600',
    },
    catalogContainer: {
        marginBottom: 20,
    },
    catalogTitle: {
        fontSize: 18,
        fontWeight: '700',
        color: '#111827',
        marginBottom: 16,
        paddingHorizontal: 4,
    },
    catalog: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 12,
    },
    boxCard: {
        width: '47%',
        backgroundColor: '#fff',
        borderRadius: 16,
        padding: 16,
        alignItems: 'center',
        borderWidth: 2,
        borderColor: '#e5e7eb',
        elevation: 2,
        shadowColor: '#000',
        shadowOpacity: 0.05,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
    },
    boxCardSelected: {
        backgroundColor: '#3b82f6',
        borderColor: '#2563eb',
        elevation: 4,
        shadowOpacity: 0.15,
    },
    boxIconContainer: {
        marginBottom: 12,
    },
    boxLabel: {
        fontSize: 16,
        fontWeight: '600',
        color: '#111827',
    },
    boxLabelSelected: {
        color: '#fff',
    },
});

export default SelectLocation;