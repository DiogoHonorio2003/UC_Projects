// Polyfills
import 'react-native-gesture-handler/jestSetup';

// Mock AsyncStorage
jest.mock('@react-native-async-storage/async-storage', () =>
    require('@react-native-async-storage/async-storage/jest/async-storage-mock')
);

// Mock fetch if we wanted to mock it, but we want REAL requests
// However, jest environment is usually jsdom/node, so we need fetch available
// React Native offers global.fetch
// jest-expo handles some of this, but we might need whatwg-fetch if environment lacks it.
// Checking environment... if Node 18+ fetch is global.
