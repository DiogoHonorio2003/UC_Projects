// Set Env Var before import
process.env.EXPO_PUBLIC_API_URL = 'http://localhost:3000';

import { getAllReservations } from '../../app/(services)/reservationsService';
import AsyncStorage from '@react-native-async-storage/async-storage';

describe('Reservations Service Integration (Node)', () => {

    it('should protect reservations endpoint (401 for invalid token)', async () => {
        (AsyncStorage.getItem as jest.Mock).mockResolvedValue('invalid-token-reservations');

        try {
            await getAllReservations();
            fail('Should have failed with 401');
        } catch (error: any) {
            console.log("Reservations Service Error:", error);
            if (error.statusCode === 401) {
                expect(error.statusCode).toBe(401);
            } else if (error.cause?.code === 'ECONNREFUSED' || error.statusCode === 0) {
                console.warn("Backend not reachable. Skipping assertion.");
                expect(true).toBe(true);
            } else {
                throw error;
            }
        }
    });

});
