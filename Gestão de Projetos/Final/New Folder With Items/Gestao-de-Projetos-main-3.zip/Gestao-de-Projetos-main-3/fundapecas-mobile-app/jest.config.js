module.exports = {
    preset: "jest-expo",
    setupFilesAfterEnv: ["./__tests__/setup.ts"],
    transformIgnorePatterns: [
        "node_modules/(?!((jest-)?react-native|@react-native(-community)?)|expo(nent)?|@expo(nent)?/.*|@expo-google-fonts/.*|react-navigation|@react-navigation/.*|@unimodules/.*|unimodules|sentry-expo|native-base|react-native-svg|nativewind|twrnc|@react-native-async-storage/async-storage)",
    ],
    moduleNameMapper: {
        "^@/(.*)$": "<rootDir>/app/$1"
    },
    testPathIgnorePatterns: ["./__tests__/setup.ts"]
};
